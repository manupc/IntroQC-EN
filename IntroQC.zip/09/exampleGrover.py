"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import ZGate
from qiskit_aer import AerSimulator

# Function that generates Grover's diffusion operator for n qubits
def GroverDiffusionOperator(n: int):

    qcG = QuantumCircuit(n)
    qcG.h(list(range(n))) # H gate for all qubits
    qcG.x(list(range(n))) # X gate for all qubits

    # Z gate controlled by n-1 qubits
    CnZGate = ZGate().control(num_ctrl_qubits=n - 1)
    qcG.append(CnZGate, list(range(n))) # Application of controlled Z gate

    qcG.x(list(range(n))) # Final X gate for all qubits
    qcG.h(list(range(n))) # Final H gate for all qubits
    return qcG


# Returns an oracle to mark the |01> state of two qubits
def Oracle01():
    qcO = QuantumCircuit(2)
    qcO.cz(control_qubit=0, target_qubit=1, ctrl_state='0')
    return qcO


# Returns an oracle to mark the |00> state of two qubits
def Oracle00():
    qcO = QuantumCircuit(2)
    qcO.x(0)
    qcO.cz(control_qubit=1, target_qubit=0, ctrl_state='0')
    qcO.x(0)
    return qcO


# Returns a two-qubit state preparation circuit
# containing the |++> state
def StatePreparation():
    qcS = QuantumCircuit(2)
    qcS.h([0, 1])
    return qcS



sim = AerSimulator() # Simulator to use

# Dictionary with the oracles to apply
Oracles = {'01': Oracle01, '00': Oracle00}

for oracle_ket in Oracles:
    oracle = Oracles[oracle_ket] # Get the oracle function

    # Circuit creation to run Grover
    qc = QuantumCircuit(2)
    qc = qc.compose(StatePreparation()) # Initial state preparation
    qc = qc.compose(oracle()) # Oracle incorporation
    qc = qc.compose(GroverDiffusionOperator(2)) # Diffusion operator
    qc.measure_all() # Measure all qubits

    # Simulation
    counts = sim.run(transpile(qc, sim), shots=1024).result().get_counts(qc)

    # Show results
    print('\nResults of Grover\'s operator on state {}'.format(oracle_ket))
    for ket in counts:
        print('\t{} : {}'.format(ket[::-1], counts[ket]))
    