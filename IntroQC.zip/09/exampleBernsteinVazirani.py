"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Implementation of the function f(x)= x.s= x0
def Fx0():
    qc = QuantumCircuit(3, 2) # 3 qb, 2 bit
    qc.cx(0, 2)
    return qc


# Instantiation of the simulator
sim = AerSimulator()

# Simulation with Deutsch-Jozsa

# Circuit construction
qc = QuantumCircuit(3, 2) # 2 qubits, 1 bit
qc.h([0, 1]) # Put x into superposition |+>
qc.x(2) # Put y into |->
qc.h(2)

# Application of f
qc = qc.compose(Fx0())

# Final Hadamard on x
qc.h([0, 1])

# Measurement
qc.measure([0, 1], [0, 1])

# Simulation
s = list(sim.run(transpile(qc, sim), shots=1).result().get_counts(qc).keys())[0]
print('The secret key of Fx0 is s={}'.format(s[::-1]))