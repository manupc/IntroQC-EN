"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, transpile
from qiskit_aer import AerSimulator
from itertools import product
import numpy as np

# Implementation of function 1
def F1():

    qx = QuantumRegister(size=3, name='qx')
    qy = QuantumRegister(size=3, name='qy')
    qc = QuantumCircuit(qx, qy)

    qc.cx(qx[0], qy[0], ctrl_state='0')
    qc.cx(qx[1], qy[1], ctrl_state='0')
    qc.cx(qx[2], qy[2])

    return qc.to_gate()


# Implementation of function 2
def F2():

    qx = QuantumRegister(size=3, name='qx')
    qy = QuantumRegister(size=3, name='qy')
    qc = QuantumCircuit(qx, qy)

    qc.x(qy[0])
    qc.ccx(qx[0], qx[1], qy[1], ctrl_state='00')
    qc.ccx(qx[0], qx[1], qy[1], ctrl_state='11')
    qc.cx(qx[2], qy[2])

    return qc.to_gate()

Fs = {1: F1, 2: F2}

# Instantiation of the simulator
sim = AerSimulator()

# Simulation with Deutsch-Jozsa
n = 3 # Bit string length
for idx in Fs:

    F = Fs[idx] # Get function

    # Circuit construction
    qc = QuantumCircuit(2 * n) # 3 input and 3 output qubits

    qc.h([0, 1, 2]) # Put x into superposition
    qc.append(F(), list(range(2 * n))) # Insert oracle
    qc.h([0, 1, 2]) # Take x out of superposition

    qc.measure_all()


    # Simulation
    qct = transpile(qc, sim)

    # Count successes N times
    aciertos = 0
    N = 5
    print('\nStarting evaluation of F{}'.format(idx))
    for i in range(N):

        # Generate possible values of s
        s = set(product(*([[0, 1]] * n)))

        # Simulate circuit
        counts = sim.run(qct, shots=2 * n).result().get_counts(qct)

        for ket in counts:
            k = [int(c) for c in ket[::-1][:n]] # Get k

            # Brute-force search for s values that satisfy s*k=0 mod 2
            s_copy = s.copy()
            for s_val in s_copy:
                if (np.dot(s_val, k) % 2 != 0) and (s_val in s):
                    s.remove(s_val)
        print('Execution {}. s is in {}'.format(i + 1, s))
        if len(s) > 2:
            print('\tCalculation error')
        elif len(s) == idx:
            aciertos += 1

    print('\nSimon was correct a total of {}/{} times'.format(aciertos, N))




