"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Implementation of the constant function f(x)=0
def Fct0():
    return QuantumCircuit(2, 1) # 2 qb, 1 bit


# Implementation of the constant function f(x)=1
def Fct1():
    qc = QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.x(1)
    return qc


# Implementation of the balanced function f(x)=x
def FbalX():
    qc = QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.cx(0, 1)
    return qc


# Implementation of the balanced function f(x)=1-x
def FbalNotX():
    qc = QuantumCircuit(2, 1) # 2 qb, 1 bit
    qc.cx(0, 1, ctrl_state='0')
    return qc


# Definition of dictionary with possible functions
func = {'f(x)=0': Fct0(), 'f(x)=1': Fct1(),
        'f(x)=x': FbalX(), 'f(x)=1-x': FbalNotX()}


# Instantiation of the simulator
sim = AerSimulator()


# Simulation of all functions
for f in func:

    # Circuit construction
    qc = QuantumCircuit(2, 1) # 2 qubits, 1 bit
    qc.h(0) # Put x into superposition |+>
    qc.x(1) # Put y into |->
    qc.h(1)

    # Application of f
    qc = qc.compose(func[f])

    # Final Hadamard on x
    qc.h(0)

    # Measurement
    qc.measure(0, 0)

    # Simulation
    state = list(sim.run(transpile(qc, sim), shots=1).result().get_counts(qc).keys())[0]
    ftype = 'f. constant' if state == '0' else 'f. balanced'
    print('Result for {} : {}'.format(f, ftype))
