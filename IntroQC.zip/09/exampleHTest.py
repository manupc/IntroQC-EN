"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


# Eigenvectors of the Z gate
svs = { '0' : Statevector.from_label('0'),
        '1' : Statevector.from_label('1')}

n_shots = 1024
for state in svs:

    # Get Z gate eigenvector
    sv = svs[state]

    # Create the circuit
    qc = QuantumCircuit(2, 1)
    qc.initialize(sv, [1])
    qc.h(0)
    qc.cz(0, 1)
    qc.h(0)
    qc.measure(0, 0)

    # Simulation
    sim = AerSimulator()
    counts = sim.run(transpile(qc, sim), shots=n_shots).result().get_counts()

    # Approximation of cos(lambda)
    prob_0s = counts['0'] / n_shots if '0' in counts else 0
    prob_1s = counts['1'] / n_shots if '1' in counts else 0

    cos_lmbda_0s = 2 * prob_0s - 1
    cos_lmbda_1s = -(2 * prob_1s - 1)
    cos_lmbda = (cos_lmbda_0s + cos_lmbda_1s) / 2

    # Eigenvalue approximation
    eigen_val = np.exp(1.j * np.arccos(cos_lmbda))
    print('The eigenvalue of the eigenvector |{}> of the Z gate is: {}'.format(state, eigen_val))
    