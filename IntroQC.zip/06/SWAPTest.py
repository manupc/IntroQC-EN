"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator
import numpy as np

theta1 = ParameterVector('theta1', 2)
theta2 = ParameterVector('theta2', 2)

# State preparation circuit
qc_prep = QuantumCircuit(3, 1)
qc_prep.rx(theta1[0], 1)
qc_prep.rz(theta1[1], 1)
qc_prep.rx(theta2[0], 2)
qc_prep.rz(theta2[1], 2)

# SWAP test circuit
qc_swap = QuantumCircuit(3, 1)
qc_swap.h(0)
qc_swap.cswap(0, 1, 2)
qc_swap.h(0)

# Final circuit
qc = qc_prep.compose(qc_swap)
qc.measure(0, 0)

# States to test
estados = { '|0>,|+>': {'theta1':[0,0],
                  'theta2':[np.pi/2,np.pi/2]},
           '|-i>,|+>': {'theta1':[np.pi/2,0],
                   'theta2':[np.pi/2,np.pi/2]},
           '|-i>,|i>': {'theta1':[np.pi/2,0],
                  'theta2':[np.pi/2,np.pi]},
           '|->,|->': {'theta1':[np.pi/2,-np.pi/2],
                  'theta2':[np.pi/2,-np.pi/2]}
         }

### Simulation
qcs = []
for s in estados:
    qc_current = qc.assign_parameters({
        theta1: estados[s]['theta1'],
        theta2: estados[s]['theta2'],
    })
    qcs.append(qc_current)
sim = AerSimulator()
qct = transpile(qcs, sim) # 'qct' is not used, could be directly 'qcs' in the run method
nshots = 1024
results = sim.run(qcs, shots=nshots).result()

# Expected results of the simulation (little endian)
for s, qc_i in zip(estados, qcs):
    counts = results.get_counts(qc_i)
    counts1 = (0 if '1' not in counts else counts['1']) / nshots
    print('d({})= {:.3f}'.format(s, counts1))