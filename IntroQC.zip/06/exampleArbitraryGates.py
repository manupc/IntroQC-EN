"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
import numpy as np


# 4-qubit quantum circuit
qc1 = QuantumCircuit(4)
qc1.h(3) # Hadamard on qubit 3
qc1.swap(0, 2) # SWAP qubits 0 and 2
qc1.ccx(0, 3, 2, ctrl_state='10'[::-1]) # Controlled-Controlled-X (Toffoli) gate: controls on qubits 0 and 3 (state |01>), target on qubit 2
qc1.cswap(1, 0, 3) # Controlled-SWAP gate: control on qubit 1, swaps qubits 0 and 3
qc1.save_statevector() # Save the statevector of the circuit


# Decomposed 4-qubit quantum circuit
qc2 = QuantumCircuit(4)

# Level 1
qc2.h(3) # Hadamard on qubit 3
qc2.swap(1, 2) # SWAP qubits 1 and 2
qc2.swap(0, 1) # SWAP qubits 0 and 1
qc2.swap(1, 2) # SWAP qubits 1 and 2

# Level 2 (Corresponds to CCX(0, 3, 2, ctrl_state='10'[::-1]) on qc1)
qc2.swap(0, 1)
qc2.swap(2, 3)
qc2.x(2) # Invert qubit 2 (originally qubit 0, which was control) to match ctrl_state '0'
qc2.ccx(1, 2, 3) # Apply Toffoli: controls on 1 and 2 (which are original 0 and 3 due to swaps), target on 3 (original 2)
qc2.x(2) # Invert qubit 2 back
qc2.swap(2, 3)
qc2.swap(0, 1)

# Level 3 (Corresponds to CSWAP(1, 0, 3) on qc1)
qc2.swap(0, 1)
qc2.swap(2, 3)
qc2.cswap(0, 1, 2) # C-SWAP: control on 0, swaps 1 and 2
qc2.swap(2, 3)
qc2.swap(0, 1)

qc2.save_statevector() # Save the statevector of the decomposed circuit


### Simulation
sim = AerSimulator()
qcs = [transpile(qc1, sim), transpile(qc2, sim)]
results = sim.run(qcs, shots=1).result()

# Expected results of the simulation
sv1 = results.get_statevector(qcs[0])
sv2 = results.get_statevector(qcs[1])

# Display the maximum difference between both vectors
diffs = np.abs(sv1.data - sv2.data)
total_diff = np.sum(diffs)
print('The distance between sv1 and sv2 is {}'.format(total_diff))
