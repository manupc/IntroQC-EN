"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import ZGate
from qiskit_aer import AerSimulator

# Creation of a controlled CCZ gate with control states '01'
CCZGate01 = ZGate().control(num_ctrl_qubits=2, ctrl_state='01'[::-1])


# Circuit to implement
qc = QuantumCircuit(3, 1)
qc.x(1) # Initialize qubit 1 to |1>
qc.h(2) # Apply Hadamard to qubit 2, creating superposition
qc.append(CCZGate01, [0, 1, 2]) # Apply the custom CCZ gate. Qubits 0 and 1 are controls, qubit 2 is target.
qc.h(2) # Apply Hadamard to qubit 2 again
qc.measure(2, 0) # Measure qubit 2 into classical bit 0

### Simulation
sim = AerSimulator()
results = sim.run(transpile(qc, sim), shots=1024).result()
counts = results.get_counts(qc)

# Simulation results (little endian)
print('Simulation results:')
for ket in counts:
    print('\t State |{}> : {} times.'.format(ket[::-1], counts[ket]))