"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import QFTGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, random_statevector
import numpy as np

# Verification of QFT and IQFT functionality
# with a random quantum state
n = 2
sv = random_statevector(dims=2**n)
print('Initial quantum state: {}'.format(sv))

# Creation of the quantum circuit
qc = QuantumCircuit(n)
qc.initialize(sv)

qft = QFTGate(num_qubits=n)
iqft = QFTGate(num_qubits=n).inverse()

qc.append(qft, list(range(n)))
qc.append(iqft, list(range(n)))
qc.save_statevector()

sim = AerSimulator()
svr = sim.run(transpile(qc, sim), shots=1).result().get_statevector()
isClose = np.all(np.isclose(sv.data, svr.data))
print('Resulting quantum state: {}'.format(svr))
print('The initial quantum state matches the final one: {}'.format(isClose))

