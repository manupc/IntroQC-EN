"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.visualization import plot_bloch_multivector
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, random_statevector
from IPython.display import display
import numpy as np

# Generates a quantum circuit with the QFT of n qubits
def QFT(n: int):

    qc = QuantumCircuit(n)

    for k in range(n):
        qc.h(k)
        for j in range(k + 1, n):
            qc.cp(theta=np.pi / (2**(j - k)), control_qubit=j, target_qubit=k)

    middle = n // 2
    for k in range(middle):
        qc.swap(k, n - k - 1)
    return qc.to_gate()

# Generates a quantum circuit with the IQFT of n qubits
def IQFT(n: int):

    qc = QuantumCircuit(n)

    middle = n // 2
    for k in range(middle - 1, -1, -1):
        qc.swap(k, n - k - 1)

    for k in range(n - 1, -1, -1):
        for j in range(n - 1, k, -1):
            qc.cp(theta=-np.pi / (2**(j - k)), control_qubit=j, target_qubit=k)
        qc.h(k)
    return qc.to_gate()

# Verification of QFT and IQFT functionality
# with a random quantum state
n = 2
sv = random_statevector(dims=2**n)
print('Initial quantum state: {}'.format(sv))

# Creation of the quantum circuit
qc = QuantumCircuit(n)
qc.initialize(sv)
qc.append(QFT(n), list(range(n)))
qc.append(IQFT(n), list(range(n)))
qc.save_statevector()

sim = AerSimulator()
svr = sim.run(transpile(qc, sim), shots=1).result().get_statevector()
isClose = np.all(np.isclose(sv.data, svr.data))
print('Resulting quantum state: {}'.format(svr))
print('The initial quantum state matches the final one: {}'.format(isClose))


# Perform QFT on computational basis kets
# of n-qubit states
for k in range(2**n):

    binket = bin(k)[2:].rjust(n, '0')
    binket = binket[::-1] # Adjust to Qiskit's little endian

    # Get the input quantum state
    sv = Statevector.from_label(binket)

    # Create the QFT circuit and simulate
    qc = QuantumCircuit(n)
    qc.initialize(sv)
    qc.append(QFT(n), list(range(n)))

    # Swap qubits due to Qiskit's little endian
    middle = n // 2
    for k_swap in range(middle): # Renamed loop variable to avoid conflict with outer 'k'
        qc.swap(k_swap, n - k_swap - 1)
    qc.save_statevector()
    svr = sim.run(transpile(qc, sim), shots=1).result().get_statevector()

    # Display Bloch spheres of each qubit for input and output states
    f = plot_bloch_multivector(sv, title='Original: |{}>'.format(k))
    display(f)
    f = plot_bloch_multivector(svr, title='QFT|{}>'.format(k))
    display(f)