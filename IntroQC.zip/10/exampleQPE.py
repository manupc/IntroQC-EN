"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import QFTGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


# Module to include QPE of X gate in the qc circuit
def QPE(qc: QuantumCircuit, b: QuantumRegister, psi: QuantumRegister):

    n = len(b)
    qc.h(b) # Initial H gate inherited from Hadamard test

    for i in range(n): # Inclusion of CU**(2**n)
        exponent = 2**i
        for j in range(exponent):
            qc.cx(control_qubit=n - i - 1, target_qubit=psi)
    for i in range(n // 2): # Convert to little endian for Qiskit's QFT
        qc.swap(i, n - i - 1)

    iqft = QFTGate(num_qubits=n) # Inverse Fourier Transform
    
    qc.append(iqft.inverse(), b)
    return qc


# Eigenvectors of the Z gate
svs = { '0' : Statevector.from_label('0'),
        '1' : Statevector.from_label('1'),
        '+' : Statevector.from_label('+'),
        '-' : Statevector.from_label('-'), }


n_shots = 2048
n = 2
for state in svs:

    # Get test vector
    sv = svs[state]

    # Circuit creation
    b = QuantumRegister(size=n, name='qb')
    cb = ClassicalRegister(size=n, name='cb')
    psi = QuantumRegister(size=1, name='qpsi')

    qc = QuantumCircuit(b, psi, cb)
    qc.initialize(sv, psi[:])
    qc = QPE(qc, b, psi)
    qc.measure(b, cb)

    # Simulation
    sim = AerSimulator()
    counts = sim.run(transpile(qc, sim), shots=n_shots).result().get_counts()

    if len(counts) != 1:
        print('\tThe state |{}> is not an eigenvector of X. Measurements: {}'.format(state, counts))
    else:
        ket = list(counts.keys())[0] # Get output ket
        binlambda = 0
        for k in range(len(ket)):
            bk = int(ket[k])
            binlambda += bk * (2**(-k - 1))
        lmbda = 2 * np.pi * binlambda
        print('Phase estimation of state |{}>: {}'.format(state, lmbda))