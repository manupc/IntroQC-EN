"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt


# Function to get N samples of a sine function with frequency freq Hz
# over duration seconds
sineWave = lambda N, duration, freq: (np.sin(2 * np.pi * np.arange(N * duration) * freq / N)).astype(np.float32)


# Function to plot
N = 100  # Number of samples (sampling frequency)
duration = 2  # Duration of the wave (seconds)

# Display functions
freq = 2  # Frequency (Hz) of the wave
faplot = 0.75 * sineWave(100, duration, freq)
freq = 3  # Frequency (Hz) of the wave
fbplot = 0.5 * sineWave(100, duration, freq)
fplot = faplot + fbplot

ts = 1 / N # Sampling period
t = np.arange(0, duration, ts) # Time instances where the wave is sampled
plt.plot(t, faplot, '--')
plt.plot(t, fbplot, '.')
plt.plot(t, fplot)
plt.legend(['fa', 'fb', 'f'])
plt.show()

