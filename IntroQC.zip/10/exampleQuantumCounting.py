"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import grover_operator, phase_estimation, ZGate
from qiskit.visualization import plot_histogram
from qiskit.quantum_info import Statevector
from qiskit.result import Counts
from qiskit_aer import AerSimulator
from IPython.display import display
import numpy as np


# Calculates an oracle that marks input states in list_states to -1
def OracleFunc(list_states: list[str], reverse_state=False):
    n = len(list_states[0])

    qc = QuantumCircuit(n)
    for state in list_states:
        rev_state = state[::-1] if reverse_state else state
        if rev_state[-1] == '0':
            qc.x(n - 1)
        mcz = ZGate().control(num_ctrl_qubits=n - 1, ctrl_state=rev_state[:-1][::-1])
        qc.append(mcz, list(range(n)))
        if rev_state[-1] == '0':
            qc.x(n - 1)
    return qc


# Returns a Statevector object with the eigenvector |G_+>
# of the Grover operator that marks the list of states list_states
# given as an argument.
def Gplus(list_states: list[str], reverse_state=False):

    n = len(list_states[0]) # No. qubits
    m = len(list_states) # No. marked states
    denM = np.sqrt(2 * m)
    denMperp = np.sqrt(2 * (2**n - m))

    # Initialize Statevector amplitudes v with |M^\perp>
    v = 1.j * np.ones(2**n, dtype=complex) / denMperp

    # Insert |M> into v
    for state in list_states:
        rev_state = state[::-1] if reverse_state else state
        int_state = int(rev_state, 2)
        v[int_state] = 1 / denM
    return Statevector(v)


n = 3 # Number of qubits on which Grover is applied
n_prec = 5 # Number of precision qubits for phase estimation

# States to be marked by the oracle
list_states = ['110', '000', '011']

# Generation of Grover's eigenvector
psi = Gplus(list_states)

# Generation of the Grover operator with the oracle
Oracle = OracleFunc(list_states)
grv = grover_operator(oracle=Oracle)

# Register for Grover
qr_grv = QuantumRegister(n, 'qrgrv')

# Registers for phase estimation
qr_phase = QuantumRegister(n_prec, 'qrphase')
cr_phase = ClassicalRegister(n_prec, 'crphase')

# Quantum circuit
qc = QuantumCircuit(qr_phase, qr_grv, cr_phase)

# Initialize Grover's eigenvector
qc.initialize(psi, qr_grv[:])

# QPE algorithm
qpe = phase_estimation(num_evaluation_qubits=n_prec, unitary=grv)

# Insertion of QPE and measurement
qc.append(qpe, qr_phase[:] + qr_grv[:])
qc.measure(qr_phase, cr_phase)

# Simulation
n_shots = 2048
sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=n_shots).result().get_counts()

# Display measurement results as a histogram
f = plot_histogram(counts)
display(f)

# Display measurement results in console
print('Measurements performed:')
for ket in counts:
    print('\t|{}> : {} times.'.format(ket, counts[ket]))


# Phase estimation
ket = Counts.most_frequent(counts)[::-1] # Get the most frequent measurement

# Calculate the approximation of theta
bintheta = 0
for k in range(len(ket)):
    bk = int(ket[k])
    bintheta += bk * (2**(-k - 1))
theta = 2 * np.pi * bintheta
print('Grover\'s phase is theta= {}'.format(theta))

# Calculate the value m
solution = np.round(2**n * np.sin(theta * 0.5)**2)
print('\nThe solution to the quantum counting problem is: {}'.format(solution))