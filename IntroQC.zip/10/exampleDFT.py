"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt

# Calculates the DFT of a discrete function given by a sequence of points f
def DFT(f: np.ndarray):

    N = len(f) # Number of samples
    ns = np.arange(N) # indices of f
    ks = ns.reshape((N, 1)) # indices of g
    exps = np.exp(-2 * np.pi * 1.j * ks * ns / N) # exponentials
    g = np.dot(exps, f)
    return g

# Calculates the inverse DFT of a discrete function given by a sequence of points g
def IDFT(g: np.ndarray):

    N = len(g) # Number of samples
    ks = np.arange(N) # indices of g
    ns = ks.reshape((N, 1)) # indices of f
    exps = np.exp(2 * np.pi * 1.j * ns * ks / N) # exponentials
    f = (np.dot(exps, g).real / N).astype(float)
    f[np.isclose(f, 0)] = 0 # Avoid approximation errors
    return f


# Function to get N samples of a sine function with frequency freq Hz
# over duration seconds
sineWave = lambda N, duration, freq: (np.sin(2 * np.pi * np.arange(N * duration) * freq / N)).astype(np.float32)


# Function to plot
N = 100  # Number of samples (sampling frequency)
duration = 2  # Duration of the wave (seconds)

# Generate functions
freq = 2  # Frequency (Hz) of the wave
fa = 0.75 * sineWave(N, duration, freq)
freq = 3  # Frequency (Hz) of the wave
fb = 0.5 * sineWave(N, duration, freq)
f = fa + fb


# Display sampled wave
ts = 1 / N # Sampling period
t = np.arange(0, duration, ts) # Time instances where the wave is sampled

fig = plt.figure()
plt.plot(t, f)
plt.plot(t, f, '.')
plt.xlabel('t')
plt.ylabel('f')
plt.show()


g = DFT(f) # Pass f to the frequency domain

# Calculate amplitudes/intensity of each individual wave
A = np.abs(g) / N
A[np.isclose(A, 0)] = 0


lenG = len(g) # Number of elements in function g
n = np.arange(lenG) # Each of the elements
Ts = lenG / N # Periods between frequencies in g
freq = n / Ts # Frequencies existing in g
fig = plt.figure()
plt.stem(freq, A, 'o')
plt.show()

# Reconstruction of f from g
f_rev = IDFT(g)
fig = plt.figure()
plt.plot(t, f)
plt.xlabel('t')
plt.ylabel('f')
plt.plot(t, f_rev, '.')


# Calculate amplitudes/intensity of each individual wave
# without duplication by symmetry
g = g[:len(g) // 2]
A = np.abs(g) / N
A[np.isclose(A, 0)] = 0


lenG = len(g) # Number of elements in function g
n = np.arange(lenG) # Each of the elements
Ts = 2 * lenG / N # Periods between frequencies in g
freq = n / Ts # Frequencies existing in g

fig = plt.figure()
plt.stem(freq[:20], A[:20], 'o')
plt.xlabel('freq. (Hz)')
plt.ylabel('A')
plt.show()





