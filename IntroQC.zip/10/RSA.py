"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






N = 253 # N=p*q, unknown
e = 233 # Public key
d = 237 # Private key

# Function to encrypt and decrypt a message with RSA
#   v: message (or encrypted message)
#   k: Public key for encryption, private key for decryption
#   N: Modular value
def RSA(v: int, k: int, N: int):
    return (v**k) % N

# Encryption of a message sequence
secuencia_m = 'HAVE FUN WITH THIS BOOK.'
print('Message to encrypt: {}'.format(secuencia_m))
encriptado = [RSA(ord(m), e, N) for m in secuencia_m]

# Transformation to text of the sequence to be sent
secuencia_cm_txt = ''.join(chr(cm) for cm in encriptado)

# Send encrypted message
print('The following encrypted message is sent: {}'.format(secuencia_cm_txt))

# Obtaining the sequence of encrypted messages at the destination
decodificado = [RSA(ord(cm), d, N) for cm in secuencia_cm_txt]
decodificado_txt = ''.join(chr(cm) for cm in decodificado)
print('The receiver has decoded: {}'.format(decodificado_txt))