"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumRegister, ClassicalRegister

# Creation of a 3-qubit quantum register
qr = QuantumRegister(size=3, name='qRegister')
print('Quantum register: ', qr)

print('Qubits in the quantum register: ')
for i in qr:
    print('\t', i)
print('First qubit: ', qr[0])


# Creation of a 3-bit classical register
cr = ClassicalRegister(size=3, name='cRegister')
print('\nClassical register: ', cr)

print('Bits in the classical register: ')
for i in cr:
    print('\t', i)
print('First bit: ', cr[0])