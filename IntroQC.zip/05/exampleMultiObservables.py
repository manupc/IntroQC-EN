"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Pauli
from qiskit_aer import AerSimulator


# Quantum circuit to prepare |10+>
qc = QuantumCircuit(3)
qc.x(0)
qc.h(2)
qc.save_statevector()

### Simulation
sim = AerSimulator(method='statevector')
qc = transpile(qc, sim)
results = sim.run(qc, shots=1).result()
sv = results.get_statevector(qc)

# Measurement of observables
observables = ['ZII', 'IZI', 'IIZ', 'IIX', 'ZIX']
for Ostring in observables:
    # Pauli expects the string in little-endian, so reverse for big-endian display
    O = Pauli(Ostring[::-1])
    E = sv.expectation_value(O)
    print('E( <10+| {} |10+> )= {:.2f}'.format(Ostring, E))