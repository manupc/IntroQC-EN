"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
import numpy as np


# Parameters to use in the circuit
theta0 = Parameter('theta0')
theta1 = Parameter('theta1')

# 2-qubit quantum circuit
qc = QuantumCircuit(2)

# Arbitrary rotation of the two qubits
qc.ry(theta=theta0, qubit=0)
qc.ry(theta=theta1, qubit=1)

qc.cx(0, 1) # CNOT gate
qc.save_statevector()


### Simulation

# Generate angles for the parameters
angles = [[0, np.pi],
          [np.pi, 0],
          [np.pi, np.pi]]

sim = AerSimulator()
qcs = [transpile(qc.assign_parameters({theta0: angle[0], theta1: angle[1]}), sim) for angle in angles]

results = sim.run(qcs, shots=1).result()

# Expected results of the simulation (little endian)
target_sv = ['10', '11', '01']
for angle, qc, sv_label in zip(angles, qcs, target_sv): # Renamed 'sv' to 'sv_label' to avoid conflict
    print('\nAngles theta0={} and theta1={}. Resulting state:'.format(angle[0], angle[1]))
    print(results.get_statevector(qc))
    print('\tExpected: ', Statevector.from_label(sv_label)) # Used sv_label here