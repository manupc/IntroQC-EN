"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np

# Calculate angle phi for rotation of q_0
phi = 2 * np.arccos(1 / np.sqrt(3))

# Quantum circuit
qc = QuantumCircuit(3)
qc.ry(phi, 0)
qc.ch(0, 1)
qc.cx(1, 2)
qc.cx(0, 1)
qc.x(0)

qc.save_statevector()

sim = AerSimulator()
sv = sim.run(transpile(qc, sim), shots=1).result().get_statevector()

# Display state vector
sv_dict = sv.to_dict(decimals=3)
print('Amplitudes of state |W>_3:')
for ket in sv_dict:
    print('\t{} : {}'.format(ket[::-1], sv_dict[ket]))

