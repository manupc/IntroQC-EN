"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

# Quantum circuit
qc = QuantumCircuit(2)
qc.x([0, 1])
qc.h(0)
qc.cx(0, 1)
qc.save_statevector()

sim = AerSimulator()
sv = sim.run(qc, shots=1).result().get_statevector(qc)

# Display state vector
sv_dict = sv.to_dict()
for ket in sv_dict:
    print('{} : {}'.format(ket[::-1], sv_dict[ket]))