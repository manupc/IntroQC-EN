"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, DensityMatrix
import numpy as np

#######
# Simulation of results with mixed states

# ket |00>
ket00 = np.zeros(4, dtype=complex)
ket00[0] = 1

# ket |10>
ket10 = np.zeros(4, dtype=complex)
ket10[1] = 1 # index 1 due to little-endian representation

# density matrix |00><00|
rho00 = ket00.reshape(-1, 1) @ ket00.reshape(1, -1)

# density matrix |01><01|
rho10 = ket10.reshape(-1, 1) @ ket10.reshape(1, -1)

# Density matrix 0.5|00><00| + 0.5|01><01|
rho = 0.5 * rho00 + 0.5 * rho10


# Creation of the density matrix
mixed = DensityMatrix(data=rho)

print('Initial mixed state:')
print(mixed)

# Quantum circuit
qc = QuantumCircuit(2)
qc.cx(0, 1)

# Simulation of the circuit
final_mixed = mixed.evolve(qc)
print('\nFinal state after simulating the circuit:')
print(final_mixed)


#######
# Simulation of the circuit with pure states
sv = Statevector((ket00 + ket10) / np.sqrt(2))
print('\nInitial pure state:')
print(DensityMatrix(sv))


# Simulation of the circuit
final_sv = sv.evolve(qc)
print('\nFinal pure state:')
print(DensityMatrix(final_sv))