"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile, QuantumRegister, ClassicalRegister
from qiskit.circuit.library import QFTGate, XGate
from qiskit_aer import AerSimulator
from fractions import Fraction
import numpy as np


# Calculates the truth table of f(k)=x**k mod N,
# for given values of x and N and 0<=k<2**n
def TruthTable(x, n, N):
    
    K= 2**n
    logN= int(np.ceil(np.log2(N)))
    table= np.zeros((n+logN, K), dtype=int)
    
    for k in range(K):
        f_k= (x**k)%N
        bink= bin(k)[2:].rjust(n, '0')
        binf_k= bin(f_k)[2:].rjust(logN, '0')
        
        intk= np.array([int(k) for k in bink], dtype=int)
        intf_k= np.array([int(f_k) for f_k in binf_k], dtype=int)
        table[:n, k]= intk[:]
        table[n:, k]= intf_k[:]
    return table

# Creates the circuit that implements the unitary matrix Uf
# to calculate f(k)= x**k mod N for given values of x and N
# with k values in 0 <= k < 2**n
def CreateUf(x : int, n: int, N : int):
    
    logN= int(np.ceil(np.log2(N)))
    table= TruthTable(x, n, N)
    
    qc= QuantumCircuit(n+logN)
    for k in range(table.shape[1]): # Column k
    
        # bit-th output bit to 1 in f(k)
        bits= n+np.where(table[n:, k] == 1)[0]

        # Create multiple controlled X gate by the k inputs               
        controls=''.join(str(table[b, k]) for b in range(n))
        mcx= XGate().control(num_ctrl_qubits=n, ctrl_state=controls)
        for bit in bits:
            qc.append(mcx, list(range(n))+[bit])
    return qc.to_gate()


# Returns the circuit to find the period of f(k)=x**k mod N,
# with 0<=k<2**n
def PeriodFindingCircuit(x:int, n:int, N:int):
    
    logN= int(np.ceil(np.log2(N)))
    
    qP= QuantumRegister(size=n)
    cP= ClassicalRegister(size=n)
    qF= QuantumRegister(size=logN)
    qc = QuantumCircuit(qP, qF, cP)
    
    # Step 1: Put K into superposition
    qc.h(qP)
    
    # Step 2: Apply Uf
    Uf= CreateUf(x, n, N)
    qc.append(Uf, qP[:]+qF[:])

    qft= QFTGate(num_qubits=n) # Step 3: QFT on K
    
    qc.append(qft, qP)
    
    # Final measurement
    qc.measure(qP, cP)
    return qc


# Finds factors of N with n bits of precision
def FindFactor(n:int, N:int, max_iter= 30, debug=True):
    
    Found= False
    iteration= 0
    while not Found:

        iteration+= 1 # Update current iteration
        if debug:
            print('Iteration: {}\n-------------'.format(iteration))
        
        # Finish due to number of iterations
        if max_iter is not None and iteration >= max_iter:
            return [None, None]
        
        # Select x
        x= np.random.randint(2, N)
        if debug:
            print('\t Selected x={}'.format(x))
        
        # If x is already a solution, return it
        gcd= np.gcd(np.int64(N), np.int64(x))
        if gcd != 1:
            if debug:
                print('GCD({},{})={}. Got lucky.'.format(N, x, gcd))
            return [gcd, 1]

        # Circuit execution to find the phase theta
        qc= PeriodFindingCircuit(x, n, N)
        sim = AerSimulator()
        counts= sim.run(transpile(qc, sim), shots=1).result().get_counts()
        ket= list(counts.keys())[0]
        
        # We find the period according to c/r= lmbda/(2**n)
        theta_K_frac = int(ket,2)/(2**n)
        if debug:
            print('\t Obtained theta/K={}'.format(theta_K_frac))
        
        # We check that lmbda != 0. Otherwise, recalculate
        if np.isclose(theta_K_frac, 0):
            continue
        
        # We calculate r
        c_r_frac= Fraction(theta_K_frac).limit_denominator(N)
        r= np.int64(c_r_frac.denominator)
            
        # We obtained an odd period, recalculate
        if r%2 != 0:
            if debug:
                print('Could not find an even r')
            continue
    
        # we get factors
        factors = [np.gcd(np.int64(x)**(r//2)-1, np.int64(N)), np.gcd(np.int64(x)**(r//2)+1, np.int64(N))]
        if debug:
            print('\t Factors found = {}'.format(factors))
            
        # We check that they are not trivial [1,N]
        for factor in factors:
            if factor not in [1,N] and (N % factor) == 0:
                Found= True
    return factors


# Function to encrypt and decrypt a message with RSA
#   v: message (or encrypted message)
#   k: Public key to encrypt, private key to decrypt
#   N: Modular value
def RSA(v:int, k:int, N:int):
    return (v**k)%N





# Example of operation
N= 77 # N=p*q, unknown
e= 17 # Public key
scm= [3, 16, 75, 18, 1, 0] # Sequence of messages to decode
n= 9  # Number of qubits to use for the approximation of r

# Quantum attack with Shor: We look for prime divisors of N
p= None
while p is None:
    factors= FindFactor(n, N) # Shor's algorithm
    if factors[0] != 1 and factors[0] != N:
        p= factors[0]
    elif factors[1] != 1 and factors[1] != N:
        p= factors[1]

print('\nObtained prime p= {} by Shor.'.format(p))

# We calculate the other prime q
q= N // p
print('The primes p and q of N=p*q are: {} and {}.'.format(p, q))

# We calculate Psi
Psi= (p-1)*(q-1)

# We look for d
for v in range(2, N):
    if (e*v)%Psi == 1:
        d= v
        break
print('I have calculated the value d= {}'.format(d))

# Message decoding
print('I am going to decode the message: {}'.format(scm))
decodificado= [ RSA(cm, d, N) for cm in scm]
print('The decoded message is: {}'.format(decodificado))