"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definitions 

# Define matrices H and Z
H = (1 / np.sqrt(2)) * np.array([
    [1, 1],
    [1, -1]
], dtype=complex)

Z = np.array([
    [1, 0],
    [0, -1]
], dtype=complex)

# Define the basis vectors (kets)
# ket_0 represents |0>
ket_0 = np.array([1, 0], dtype=complex)

# ket_1 represents |1>
ket_1 = np.array([0, 1], dtype=complex)


# Calculations 

# Calculate the first operation: H * Z * H * |0>
r_1 = H @ Z @ H @ ket_0

# Calculate the second operation: Z * H * Z * |1>
r_2 = Z @ H @ Z @ ket_1


# Show Results

print("Initial Matrices and Vectors")
print("Matrix H:\n", H)
print("\nMatrix Z:\n", Z)
print("\nVector |0>:", ket_0)
print("\nVector |1>:", ket_1)
print("\n\n")

print("Operation Results")

print("Result of HZH|0>: {}".format(np.round(r_1, decimals=5)))
print("Result of ZHZ|1>: {}".format(np.round(r_2, decimals=5)))