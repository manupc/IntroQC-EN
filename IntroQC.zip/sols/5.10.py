"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator


qc= QuantumCircuit(3)
qc.x(2)
qc.h([0,1,2])
qc.cx(0,2)
qc.cx(1,2)
qc.h([0,1])
qc.measure_all()



sim= AerSimulator()
n_shots= 1000
counts= sim.run(transpile(qc, sim), shots=n_shots).result().get_counts()
for ket in counts:
    be_ket= ket[::-1] # Resultado en big endian
    print('We get |{}> with approx. probability {}'.format(be_ket, counts[ket]/n_shots))
    if be_ket[0] != '0':
        print('\tPHASE KICKBACK at qubit 0')
    if be_ket[1] != '0':
        print('\tPHASE KICKBACK at qubit 1')
