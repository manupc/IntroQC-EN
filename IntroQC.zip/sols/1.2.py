"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create array
a = np.array([25, 30, 22, 35, 28])

# Calculate the average, minimum and maximum
avg_a, min_a, max_a = np.mean(a), np.min(a), np.max(a)

# Print the results
print("The age array is: {}".format(a))
print("The average age is: {:.2f}".format(avg_a))
print("The minimum and maximum ages are: {} and {}".format(min_a, max_a))