"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.circuit import ParameterVector
import numpy as np


qc = QuantumCircuit(5, 2) # 3 inputs, 2 outputs (negative, positive)

# input encoding
par = ParameterVector(name='par', length=3)
for i in range(len(par)):
    qc.ry(par[i]*np.pi, i)


# R1: 
qc.cx(2, 3, ctrl_state='0')

# R2: Sine of 1 and Sine of 2 < 0 -> positive
qc.ccx(0, 1, 4, ctrl_state='00')

# R3: Angular velocity of 2 > 0 -> positive
qc.cx(2, 4)

qc.measure([3, 4], [1,0]) # little endian

sim = AerSimulator()


# Function to select action from state s with the quantum circuit qc
def a(s, qc, sim):
    sin1, sin2, w2 = (s[1]+1)/2, (s[3]+1)/2, (s[5]+9*np.pi)/(18*np.pi)
    
    rotations = [sin1, sin2, w2]
    
    # Circuit execution
    counts = sim.run(transpile( qc.assign_parameters(rotations), sim ), shots=100).result().get_counts()
    action_counts = [
        0 if '10' not in counts else counts['10'],
        0 if '01' not in counts else counts['01']
        ]
    
    action = int(np.argmax(action_counts)*2)
    return action
    
    


env = gym.make('Acrobot-v1')
s, _ = env.reset()
R = 0 # Total reward

end = False
maximum = 1000
t = 0
while not end:
    
    action = a(s, qc, sim)
    # In state s({})={} I choose a(s({}))= {}
    print('In state s({})={} I choose a(s({}))= {}'.format(t, s, t, action))
    sp, r, t1, t2, _ = env.step(action)
    R += r
    t += 1
    end = t1 or t2 or t >= maximum
    s = sp

# Finished in {} steps with R={}
print('Finished in {} steps with R={}'.format(t, R))