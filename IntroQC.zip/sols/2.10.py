"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import DensityMatrix


# Generation of the states
mat = [np.array([[1, 0], [0, 0]], dtype=complex),
       np.array([[0.5, 0], [0, 0.5]], dtype=complex),
       np.array([[0.75, 0], [0, 0.25]], dtype=complex),
       np.array([[0.5, 0.5], [0.5, 0.5]], dtype=complex)
      ]

# We iterate over all of them
for m in mat:

    dm = DensityMatrix(m) # Convert to density matrix
    
    print('-'*10)
    print('Density Matrix:\n', dm)
    print('\tTrace: {}'.format(dm.trace()))
    print('\tPurity: {}'.format(dm.purity()))
    
    # Try to convert to Statevector
    try:
        dm.to_statevector()
        print('The state is pure')
    except:
        print('The state IS NOT pure')
    