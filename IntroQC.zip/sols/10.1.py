"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.circuit.library import QFTGate
from qiskit.visualization import plot_histogram
from IPython.display import display

n=3 # Number of qubits

qc= QuantumCircuit(n)
qc.h(range(n)) # Move to |+>
qc.append(QFTGate(n), range(n))
qc.measure_all()

sim= AerSimulator()

n_shots= 1000
counts= sim.run( transpile(qc, sim), shots=n_shots).result().get_counts()

display(plot_histogram(counts))
print('The only possible state is ', list(counts.keys()))