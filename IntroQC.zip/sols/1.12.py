"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Original vector v
v = np.array([2, 3])
print("Original vector v: {}".format(v))

# Apply linear transformation
vp_1 = 2 * v[0] + 1 * v[1]
vp_2 = 3 * v[1] 

# Create the transformed vector 
vp = np.array([vp_1, vp_2])
print("Transformed vector v': {}".format(vp))

# Calculation and application of the inverse function
vr_1 = vp[0]/2 - vp[1]/6
vr_2 = vp[1]/3

# Create the recovered vector
vr = np.array([vr_1, vr_2])
print("Recovered vector after inverse transformation: {}".format(vr))

# Check if the recovered vector is essentially the same as the original
if np.allclose(v, vr):
    print("\nVerification successful! The original vector was recovered correctly.")
else:
    print("\nWarning: The original vector was not recovered exactly. There might be precision issues.")