"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the complex matrix Y
Y = np.array([
    [0, -1j],
    [1j, 0]
])

# Check if it is Hermitian
hermi = np.allclose(Y, np.conjugate(Y).T)

# Check if it is Unitary
I = np.identity(2)
prod = np.conjugate(Y).T @ Y
unitary = np.allclose(prod, I)

# Show the results
print("Matrix Y:\n", Y)

# Result of the Hermitian check
if hermi:
    print("The matrix Y is Hermitian.")
else:
    print("The matrix Y IS NOT Hermitian.")

# Result of the Unitary check
if unitary:
    print("The matrix Y is Unitary.")
else:
    print("The matrix Y IS NOT Unitary.")