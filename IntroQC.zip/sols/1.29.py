"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Parameter Definitions 

N = 1000000 # N is the total number of random points to generate.
l = 1.0 # Length of the square's side
r = l / 2 # radius of the circle

# Point Generation
pt = np.random.uniform(low=0.0, high=1.0, size=(N,2))

# Check Points Inside the Circle
d = np.sum((pt-0.5)**2, axis=1)


# Count how many points meet the condition of being inside the circle.
circ = np.sum(d <= r**2)

# Probability Approximation of being inside the circle
p = circ / N

# Pi is solved from the formula p = (pi * r^2) / l^2
a_pi = 4*p

# Show Results
print("Total number of points generated: {}".format(N))
print("Points that fell inside the circle: {}".format(circ))
print("Point ratio (p): {:.4f}".format(p))
print("Approximation of π: {:.6f}".format(a_pi))