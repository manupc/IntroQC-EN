"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Generation of the problem matrix
n=6
M= np.zeros((n,n), dtype=int)
for i in range(n):
    for j in range(n):
        if i!= j:
            M[i][j]= i+j

# Initial problem representation with the adjacency matrix:
print('Initial problem representation with the adjacency matrix:')
print(M)

# Creation of variables for the Ising model
z = Array.create('z', shape=(len(M),), vartype='SPIN')

# Problem coefficients matrix and formulation
Ising= 0 # Ising model

# Cost function formulation
for i in range(M.shape[0]):
    for j in range(i+1, M.shape[1]):
        if M[i,j] != 0:
            
            # Ising model: Adds M[i,j] if z[i] == z[j], subtracts M[i,j] if z[i] != z[j]
            Ising+= M[i, j]*z[i]*z[j]

model= Ising.compile()
ising_description= model.to_ising()

# Ising Model:
print('\nIsing Model:')
for coefs in ising_description:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])

# Create binary quadratic model (BQM)
bqm= model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
# The {} solutions obtained: 
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Obtaining the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

solution = np.zeros(len(M), dtype=int)
for var in best_sample_vars:
    for i, z_i in enumerate(z):
        if var in str(z_i):
            solution[i] = best_sample_vars[var]

# Best Solution: z={} with cost f(x)={}
print('\nBest Solution: z={} with cost f(x)={}'.format(solution, best_sample_cost))