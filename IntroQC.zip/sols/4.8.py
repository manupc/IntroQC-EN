"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np


# State preparation
qc_prep= QuantumCircuit(1)
qc_prep.x(0)


# Ansatz
qc_ans= QuantumCircuit(1)
qc_ans.ry(np.pi/2, 0)


qc= qc_prep.compose(qc_ans)

# Measurement in X
qc.h(0)
qc.save_statevector()
sim= AerSimulator()

sv= sim.run(transpile(qc), shots=1).result().get_statevector()
p= sv.probabilities_dict()
for ket in p:
    k= '+' if ket == '0' else '-'
    print('Measurement probability of |{}>: {}'.format(k, p[ket]))

