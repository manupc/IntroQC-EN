"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the matrix M
M = np.array([[4, 1],
              [2, 3]])

print("Matrix M:\n", M)

# Calculate eigenvalues and eigenvectors
eigenvalues, eigenvectors = np.linalg.eig(M)

print("\nEigenvalues:", eigenvalues)
print("\nEigenvectors (each column is an eigenvector):\n", eigenvectors)

# 3. Verify the relationship Mv = λv for each pair
print("\nVerification of Mv = λv:")

# Iterate over each eigenvalue-eigenvector pair
for i in range(len(eigenvalues)):
    lambda_val = eigenvalues[i]
    v_vec = eigenvectors[:, i] 

    # Calculate M * v
    Mv = M @ v_vec

    # Calculate lambda * v
    lambdav = lambda_val * v_vec

    print("\nFor the pair:")
    print("\tEigenvalue (λ): {:.4f}".format(lambda_val))
    print("\tEigenvector (v): {}".format(v_vec))
    print("\tMv: {}".format(Mv))
    print("\tλv: {}".format(lambdav))

    # Check if Mv is approximately equal to λv
    # We use np.allclose() due to floating-point precision
    if np.allclose(Mv, lambdav):
        print("Mv = λv")
    else:
        print("Mv != λv. There is a problem.")