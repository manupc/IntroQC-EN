"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generation of the states
# Labels
labels = ['+', 'r', '0', 'l', '-', '1']

# We iterate over all labels
for i, label1 in enumerate(labels):
    
    sv1 = Statevector.from_label(label1)
    
    for j, label2 in enumerate(labels):
        if j > i:
            sv2 = Statevector.from_label(label2)
            
            inner = sv1.inner(sv2)
            if np.isclose(inner, 0):
                # |{}> and |{}> can form a basis
                print('|{}> and |{}> can form a basis'.format(label1, label2))
