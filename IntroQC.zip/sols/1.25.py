"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the Hermitian matrix Z
Z = np.array([
    [1, 0],
    [0, -1]
])

# Define the column vector v
v = np.array([
    [1 / np.sqrt(2)],
    [1j / np.sqrt(2)]
])

# Calculate the conjugate transpose of v (v-dagger)
v_dagger = np.conjugate(v).T

# Calculate the value E = v† * Z * v
E = v_dagger @ Z @ v

# Show the results
result = E.squeeze().item()

print("Vector v:\n", v)
print("\nMatrix Z:\n", Z)
print("\nCalculated value of E = v† Z v: {}".format(result))
print("Imaginary part of E: {}".format(result.imag))


# Final check
if np.isclose(result.imag, 0):
    print("The result E is a real number, as expected.")
else:
    print("The result E is not a real number.")