"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator


# Decoder circuit
qcd = QuantumCircuit(2+4, 4)

# Initially decode as 1000
qcd.x(2)

# Case where the state is 1x -> decodes as 0010 or 0001
qcd.cswap(0, 2, 4)

# Case where the state is 01 -> decodes as 0100
qcd.cswap(1, 2, 3)

# Case where the state is 11 -> decodes as 0001
qcd.cswap(1, 4, 5)

qcd.measure([2, 3, 4, 5], [0, 1, 2, 3]) 

# Simulation
lst = ['000000', '010000', '100000', '110000']
sim = AerSimulator()
for str_sv in lst:
    sv = Statevector.from_label(str_sv[::-1]) # Handle little endian
    qc_prep = QuantumCircuit(2+4, 4)
    qc_prep.initialize(sv)
    
    qc = transpile(qc_prep.compose(qcd), sim)
    result = list(sim.run(qc, shots=1).result().get_counts().keys())[0][::-1] # Handle little endian
    
    print('{} is decoded as {}'.format(str_sv[:-4], result))