"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create the rs array
rs = np.linspace(1.0, 10.0, 5)

# Create the a array with 5 angles uniformly spaced between 0 and 2*pi
a = np.linspace(0, 2 * np.pi, 5)

print('Pairs (radius, angle):')
for r_elm, a_elm in zip(rs, a):
    print('\t{} - {}'.format(r_elm, a_elm))

# Calculate the Cartesian coordinates x and y
x = rs * np.cos(a)
y = rs * np.sin(a)


print("\nCartesian Coordinates (x, y):")
for x_elm, y_elm in zip(x, y):
    print('({} , {})'.format(x_elm, y_elm))
