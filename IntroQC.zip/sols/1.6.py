"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create a NumPy array with angles in degrees
ad = np.array([0, 30, 45, 60, 90, 180])

# Convert the angles from degrees to radians
ar = np.deg2rad(ad)

# Calculate the sine of each angle in radians
sin = np.sin(ar)

# Print all arrays
print("Original angles in degrees: {}".format(ad))
print("Angles in radians: {}".format(ar))
print("Sine of the angles: {}".format(sin))