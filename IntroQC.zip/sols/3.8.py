"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
from qiskit.quantum_info import state_fidelity


# State
sv= Statevector([0.6, 0.8j])

# Circuit initialization
qc= QuantumCircuit(1)
qc.initialize(sv)

# Allowed quantum gates
gates = ['h', 's', 'sdg', 'sx', 'sxdg', 't', 'tdg']

# Circuit decomposition
qc_gen = transpile(qc, basis_gates=gates, optimization_level=3)
print(qc_gen.draw('text'))


# Simulation
qc_gen.save_statevector()
sim= AerSimulator(method='statevector')

sv_res= sim.run(qc_gen, shots=1).result().get_statevector()

# fidelity
f= state_fidelity(sv, sv_res)
print('Fidelity of states: ', f)