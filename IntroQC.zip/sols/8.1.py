"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.circuit import Parameter

# Circuit
par= Parameter('par')
qc= QuantumCircuit(1) 
qc.h(0)
qc.rz(par, 0)
qc.h(0)
qc.measure_all()

# Angle values
thetas= [np.pi, np.pi/2]

nshots= 1000
sim= AerSimulator()


lqc= [ transpile(qc.assign_parameters({par : theta}), sim) for theta in thetas ]


r= sim.run(lqc, shots= nshots).result()
for theta, qct in zip(thetas, lqc):
    print('For theta={}'.format(theta))
    counts= r.get_counts(qct)
    for k in counts:
        print('\tWe get {}, {}% of times'.format(k, counts[k]/nshots*100))
    
print('When the magnetic field aligns, it collapses to the same value. When it is not aligned, it collapses to one of two values.')