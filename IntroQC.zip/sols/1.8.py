"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create angles
x = np.linspace(0, np.pi, 10)

# Calculate sine and cosine
s = np.sin(x)
c = np.cos(x)

# Square them
s2 = s**2
c2 = c**2

# Sum the elements of the identity
I = s2 + c2

# Print the results to the console
print("Values of x: {}".format(x))
print("Results of sin^2(x) + cos^2(x): {}".format(I))

# Are all values close to 1?
V = np.allclose(I, 1)
print("Are all values very close to 1? : {}".format(V))
