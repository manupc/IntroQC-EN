"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create the temperature array
t = np.array([24.6, 18.3, 29.5, 27, 22.8, 15, 22.1])

print("Daily temperatures: {}".format(t))

# Calculate mean, minimum and maximum
avg_t, min_t, max_t = t.mean(), t.min(), t.max()

print("Maximum temperature: {:.1f}°C".format(max_t))
print("Minimum temperature: {:.1f}°C".format(min_t))
print("Average temperature: {:.1f}°C".format(avg_t))

# Select and display temperatures above 24.0
high_t = t[t > 24.0]

print("Temperatures above 24.0°C: {}".format(high_t))