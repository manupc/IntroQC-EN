"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Given arrays
A = np.array([10, 5, 3, 8])
B = np.array([10, 6, 4, 7])

All = np.vstack((A, B)) # Combine arrays into a 2x4 matrix

print("Average grades per student: {}".format(np.mean(All, axis=0)))
print("Group average grade: {}".format(np.mean(All)))

# Calculate difference B-A
diff = np.diff(All, axis=0)
print("Evolution of each student: {}".format(diff))

# 10% increase on the first exam, not exceeding 10
Ainc = 1.1 * A
Ainc[Ainc > 10] = 10
print("First exam with 10% increase: {}".format(Ainc))