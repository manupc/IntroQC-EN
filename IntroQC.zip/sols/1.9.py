"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Create array
x = np.array([0.0, 0.5, np.sqrt(2)/2, np.sqrt(3)/2, 1.0])

# Calculate the corresponding angles in radians using np.arcsin()
ar = np.arcsin(x)

# Convert the angles from radians to degrees using np.rad2deg()
ad = np.rad2deg(ar)

# Show the three arrays on the console
print("Array of sine values: {}".format(x))
print("Corresponding angles in radians: {}".format(ar))
print("Corresponding angles in degrees: {}".format(ad))
