"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Global Definitions 

# Matrix H
H = (1/np.sqrt(2))*np.array([[1, 1], [1, -1]], dtype=complex)

# Matrix Z 
Z = np.array([[1, 0], [0, -1]], dtype=complex)

# Basis vectors |0> and |1>
ket_0 = np.array([1, 0], dtype=complex)
ket_1 = np.array([0, 1], dtype=complex)

# Verification Function
# This function takes two kets (u, v) and checks if the property holds.
def check(ket_u, ket_v):
    print("\nChecking for |u> = {} and |v> = {}".format(ket_u, ket_v))

    # LEFT SIDE: (H|u>) ⊗ (Z|v>)
    Hu = H @ ket_u
    Zv = Z @ ket_v
    lhs = np.kron(Hu, Zv)

    # RIGHT SIDE: (H ⊗ Z) |uv> 
    H_tensor_Z = np.kron(H, Z)
    ket_uv = np.kron(ket_u, ket_v)
    rhs = H_tensor_Z @ ket_uv

    # Comparison and Result
    comp = np.allclose(lhs, rhs)

    if comp:
        print("\tThe property holds. Both sides are equal to {}".format(np.round(lhs, decimals=5)))
        
    else:
        print("\tThe property DOES NOT hold.")
    
    print("-" * 50)

# Execution of the four cases
check(ket_0, ket_0)
check(ket_1, ket_1)
check(ket_0, ket_1)
check(ket_1, ket_0)