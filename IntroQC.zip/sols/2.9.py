"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector, DensityMatrix


# Generation of the states
st = [ Statevector([np.sqrt(0.25), np.sqrt(0.75)]),
       Statevector([np.sqrt(0.25), -np.sqrt(0.75)])]

# We iterate over all of them
for sv in st:

    dm = DensityMatrix(sv) # Convert sv to density matrix
    
    print('-'*10)
    print('State {}'.format(sv))
    print('Density Matrix:\n', dm)
    print('State with to_statevector: {}'.format(dm.to_statevector()))