"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator
import numpy as np

# Data
XNOR= np.array([[0,0,1],
                [0,1,0],
                [1,0,0],
                [1,1,1],
                ])

# Data encoding
par= ParameterVector(name='par', length=2)
qc_prep= QuantumCircuit(3, 1)
qc_prep.h(2)
qc_prep.ry(par[0]*np.pi, 0)
qc_prep.ry(par[1]*np.pi, 1)


# Ansatz
qc_ant= QuantumCircuit(3, 1)
qc_ant.cz(0,2)
qc_ant.cz(1,2)
qc_ant.h(2)
qc_ant.x(2)

# Circuit
qc= qc_prep.compose(qc_ant)
qc.measure(2,0)
# Simulation
sim= AerSimulator(method='statevector')
lqc= []
for data in XNOR:
    X,y= data[:2], data[2]
    lqc.append(qc.assign_parameters({par : X}))

r= sim.run(lqc, shots=1).result()
for data, circ in zip(XNOR, lqc):
    X, y= data[:2], data[2]
    ket= int( list(r.get_counts(circ).keys())[0] )
    # For data {} it returns {} and should return {}
    print('For data {} it returns {} and should return {}'.format(X, ket, y))
