"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the original vector in the canonical basis
v = np.array([5, -1])
print("Original vector v: {}".format(v))

# Define the vectors of the new orthonormal basis
u1 = np.array([0.6, 0.8])
u2 = np.array([-0.8, 0.6])
print("\nNew basis vector u1: {}".format(u1))
print("New basis vector u2: {}".format(u2))

# Calculate the new coordinates (vp_1, vp_2)
# v'_1 = <v, u1> (dot product of v and u1)
vp_1 = np.dot(v, u1)

# v'_2 = <v, u2> (dot product of v and u2)
vp_2 = np.dot(v, u2)

# Create a new array for the vector in the new basis
vp = np.array([vp_1, vp_2])

print("\nVector v in the new basis B': {}".format(vp))