"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generation of the states
ls = [ # List of states
      Statevector([np.exp(2*np.pi*1j), 0]),
      Statevector([np.sqrt(2)/2, 1j*np.sqrt(2)/2]),
      Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
      Statevector([np.sqrt(2)/2, np.sqrt(2)/2]),
      Statevector([0, np.exp(2*np.pi*1j)]),
      Statevector([1/np.sqrt(2), -1j/np.sqrt(2)])
    ]

# Computational basis vectors
ket0 = Statevector([1, 0])
ket1 = Statevector([0, 1])

# We iterate over all states
for ket in ls:
    print('-'*10)
    print('State {}'.format(ket))
    print('Validity : {}'.format(ket.is_valid()))
    
    # Comparison with computational basis
    isket0 = ket == ket0
    isket1 = ket == ket1
    
    if isket0:
        print('Equivalent to |0>')
    elif isket1:
        print('Equivalent to |1>')
    else:
        print('Non-standard superposition state')