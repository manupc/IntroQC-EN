"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import XGate
from qiskit_ibm_runtime.fake_provider import FakeSherbrooke as Simulator
from qiskit.visualization import plot_histogram
from IPython.display import display



# Modular circuit: 1-qubit Adder
def SingleQubitAdder():
    
    # CCCNOT Operation
    CCCNOT_001= XGate().control(num_ctrl_qubits=3, ctrl_state='001'[::-1])
    CCCNOT_110= XGate().control(num_ctrl_qubits=3, ctrl_state='110'[::-1])
    
    # Qubit assignment:
    #  q0: q_x; q1: q_y; q2: q_c; q3: q_z
    adder= QuantumCircuit(4, name='Adder')
    
    # Calculation of qz= q_x+q_y+q_c
    adder.cx(0, 3)
    adder.cx(1, 3)
    adder.cx(2, 3)
    
    # Update CARRY
    adder.append(CCCNOT_001, [0, 1, 3, 2])
    adder.append(CCCNOT_110, [0, 1, 3, 2])
    return adder.to_instruction()



# Input and output quantum registers
qx= QuantumRegister(size=1, name='qx')
cx= ClassicalRegister(size=1, name='clx')
qy= QuantumRegister(size=1, name='qy')
cy= ClassicalRegister(size=1, name='cly')
qz= QuantumRegister(size=1, name='qz')
cz= ClassicalRegister(size=1, name='clz')
qcarry= QuantumRegister(size=1, name='qcarry')
ccarry= ClassicalRegister(size=1, name='ccarry')

# Adder circuit
adder= SingleQubitAdder()

# Circuit with quantum parallelism
qc= QuantumCircuit(qx, qy, qz, qcarry, cx, cy, cz, ccarry)
qc.h(qx)
qc.h(qy)
qc.append(adder, qx[:]+qy[:]+qz[:]+qcarry[:])
qc.measure(qx, cx)
qc.measure(qy, cy)
qc.measure(qz, cz)
qc.measure(qcarry, ccarry)


# Access to the quantum computing service
backend = Simulator()
print('Assigned back-end: {} with {} qubits.'.format(backend.name, backend.num_qubits))


# We transform the circuit to the instruction set of the assigned quantum computer
qct= transpile(qc, backend)

# Show transpiled circuit
f= qct.draw('mpl')
display(f)

print('Job queued. Waiting for our turn...')
results= backend.run([qct], shots= 1024).result()
counts= results.get_counts() # We get the no. of times of each possible measurement
    
# xyzc truth table
table= ['0000',
        '0110',
        '1010',
        '1101']

print('\nResults: ')
errores= 0
for ket in counts:
    rket= ket[::-1]
    x= int(rket[0])
    y= int(rket[2])
    z= int(rket[4])
    c= int(rket[6])
    result= str(x)+str(y)+str(z)+str(c)
    if result not in table:
        print('\tERROR: The calculation {}+{} is not z={} and c={}'.format(x,y,z,c))
        errores+= 1
    else:
        print('OK: The calculation {}+{} is z={} and c={}'.format(x,y,z,c))
f= plot_histogram(counts)
display(f)
print('Error percentage: {}%'.format(errores/1024*100))