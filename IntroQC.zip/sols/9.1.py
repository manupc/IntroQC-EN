"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator


# Implementation of the 3-element XOR function
def FXOR():
    qc = QuantumCircuit(4) 
    qc.cx(0,3)
    qc.cx(1,3)
    qc.cx(2,3)
    return qc


# Simulator instantiation
sim = AerSimulator()

# Circuit construction
qc = QuantumCircuit(4, 3) 
qc.h([0,1,2]) # Put x into superposition |+>
qc.x(3) # Put y into |->
qc.h(3)

# Application of f
qc = qc.compose( FXOR() )

# Final Hadamard on x
qc.h([0,1,2])

# Measurement
qc.measure([0, 1, 2], [0, 1, 2])

# Simulation
states = list(sim.run(transpile(qc, sim), shots=1000).result().get_counts(qc).keys())
if len(states) != 1:
    raise Exception('ERROR: Obtained '+str(states))
else:
    state = states[0]
    print('Ok. A single state was obtained: ', state)
    
    
ftype = 'f. const' if state == '000' else 'f. bal.'
print('Result : {}'.format(ftype))

    
    
    