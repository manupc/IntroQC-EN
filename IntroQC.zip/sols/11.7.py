"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler



# Generation of the problem matrix
S= np.array([1, 2, 3, 4, 5, 6], dtype= int)
n= len(S)
# Initial problem representation:
print('Initial problem representation:')
print(S)


# Creation of variables for the Ising model
z = Array.create('z', shape=(n,), vartype='SPIN')

# Problem coefficients matrix and formulation
Ising= 0 # Ising model

# Cost function formulation
for i in range(len(S)):
    # QUBO Model: S[i]*z[i] adds S[i] when z[i]=1 and subtracts it when z[i]=-1
    Ising+= S[i]*z[i]
Ising= Ising**2 # Squared so that the difference is positive


model= Ising.compile()
ising_description= model.to_ising()

# Ising Model:
print('\nIsing Model:')
for coefs in ising_description:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])

# Create binary quadratic model (BQM)
bqm= model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
# The {} solutions obtained: 
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Obtaining the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

solution = np.zeros(n, dtype=int)
for var in best_sample_vars:
    for i, z_i in enumerate(z):
        if var in str(z_i):
            solution[i] = best_sample_vars[var]
    
# Best Solution: z={} with cost f(x)={}
print('\nBest Solution: z={} with cost f(x)={}'.format(solution, best_sample_cost))