"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
import numpy as np

# Example data
sqr_amplitudes = np.array([0.4, 0.3, 0.2, 0.1])

# Calculate probabilities of qubits being in |0> or |1>
p_q0_0 = np.sum(sqr_amplitudes[:2]) # p(q0=|0>)
p_q1_0_cond_q0_0 = sqr_amplitudes[0]/p_q0_0 # p(q1=|0>|q0=|0>)
p_q1_0_cond_q0_1 = sqr_amplitudes[2]/(1-p_q0_0) # p(q1=|0>|q0=|1>)

# Convert probabilities to rotations
rq0 = 2*np.arccos(np.sqrt(p_q0_0))
rq1_cond_q0_0 = 2*np.arccos(np.sqrt(p_q1_0_cond_q0_0))
rq1_cond_q0_1 = 2*np.arccos(np.sqrt(p_q1_0_cond_q0_1))



# Circuit
qc = QuantumCircuit(2)
qc.ry(rq0, 0)
qc.cry(rq1_cond_q0_0, 0, 1, ctrl_state='0')
qc.cry(rq1_cond_q0_1, 0, 1)
qc.swap(0,1) # To switch from little endian to big endian
qc.save_statevector()


# Simulation
sim = AerSimulator(method='statevector')
sv = sim.run(qc, shots=1).result().get_statevector()
print('Resulting state: ', sv)
print('Probabilities:')
svd = sv.probabilities_dict()
for ket in svd:
    idx = int(ket, 2)
    # and should be
    print('\t', ket, svd[ket], 'and should be', sqr_amplitudes[idx])
