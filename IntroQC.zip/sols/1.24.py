"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the vector v and the matrix U
v = (1 / np.sqrt(2)) * np.array([0, 1, 1, 0])
U = np.array([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0]
])

# Calculate the resulting vector w = U * v
w = U @ v

# Calculate the norm of vectors v and w
norm_v = np.linalg.norm(v)
norm_w = np.linalg.norm(w)

# Check if the norms are equal
comp = np.allclose(norm_v, norm_w)

# Show the results
print("Original vector v:\n", v)
print("Unitary matrix U:\n", U)
print("\nResulting vector w = U @ v:\n", w)

print(f"Norm of v: {norm_v:.4f}")
print(f"Norm of w: {norm_w:.4f}")

if comp:
    print("The norm of the vector has been preserved after the transformation.")
else:
    print("The norm of the vector has changed.")