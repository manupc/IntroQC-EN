"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Circuit
qc= QuantumCircuit(2,1)
qc.x(1)
qc.h([0,1])
qc.x(0)
qc.cx(0,1)
qc.x(0)
qc.h(0)
qc.measure(0,0)

nshots= 1000
sim= AerSimulator()
counts= sim.run(transpile(qc, sim), shots=nshots).result().get_counts()
for k in counts:
    print('We obtain {}  {}% of times'.format(k, counts[k]/nshots*100))

print('We can see a phase kickback from q1 to q0')