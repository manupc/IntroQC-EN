"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from itertools import product


###########################################################
# BRUTE FORCE METHOD 
###########################################################


# Exact brute force algorithm to find 
# the optimal solution to an optimization problem (minimization)
# As input, it needs the number of variables of the problem (n), a list D of
# n lists with the possible values for each variable, a function
# boolean constraints_f(x) to verify that a solution x to the problem meets
# its constraints (returns True) or not (returns False), 
# and a cost function cost_f(x) that returns the cost of a solution
# As output, it returns an optimal solution x to the problem (np.ndarray)
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx= None # Initialization of the optimal solution
    fbx= np.inf # Cost of the optimal solution
    
    all_solutions_generator= product(*D) # Generator of all possible solutions
    for x in all_solutions_generator:
        
        x= np.array(x)
        
        # Check if x meets the constraints
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx= cost_f(x) # Calculate the cost of the solution
        if fx < fbx: # We update the best solution found
            bx, fbx= x, fx
    return np.array(bx)





###########################################################
# SIMULATED ANNEALING METHOD 
###########################################################


# Simulated annealing algorithm. It needs:
#   x_init: Initial valid solution to the problem
#   cost_f: Cost function cost_f(x)
#   neighbor_f: Neighbor generation function neighbor_f(x)
#   T_init: Initial temperature
#   T_factor: Multiplicative cooling factor for the temperature
#   max_iter: Maximum iterations of the algorithm without improvement of the best solution
# Returns a solution x to the problem (np.ndarray)
def SA_optimizer(x_init : np.ndarray, cost_f : callable, 
                 neighbor_f : callable, T_init : float, T_factor : float, 
                 max_iter : int):
    
    # Parameter initialization
    T= T_init # Temperature
    x, fx= x_init.copy() , cost_f(x_init) # Current solution and cost
    bx, fbx = x.copy(), fx # Best solution found so far and its cost
    
    iter_count= 0 # Counter for the number of algorithm iterations without improvement of bx
    while iter_count < max_iter: # Main loop
    
        update= False # To check if we have updated the best solution
    
        # Generate a neighboring solution
        xp= neighbor_f(x) 
        fxp = cost_f(xp)
        
        # Decision on accepting the generated solution
        f_diff= fxp - fx
        
        # If the new solution is better, we always accept it.
        # If it is worse, we accept it with a decreasing probability (Metropolis Criterion).
        if f_diff < 0 or np.random.uniform() < np.exp(-f_diff / T):
            x, fx = xp, fxp
            
            # We update the best solution found so far if necessary
            if fx < fbx:
                bx, fbx = x.copy(), fx
                update= True

        # We reset the iteration counter because we have improved
        # or update it if not
        iter_count= 0 if update else iter_count+1
            
        # Cooling of the system
        T*= T_factor

    return bx


# Function to return a neighboring solution to solution x
# Modifies a random component 
def neighbour_generator(x : np.array):

    x_prime= x.copy()
    pos= np.random.randint(low=0, high=len(x), size=2)
    x_prime[pos]= 1-x_prime[pos]
    return x_prime




###########################################################
# COST FUNCTION 
###########################################################


# Procedure to implement the cost function. It takes as input
# the solution x and the set of numbers S from the problem.
# As output, it returns a scalar value with the cost function
def f(x : np.ndarray, S : np.ndarray):
    return np.abs( np.sum( S[x==0] ) - np.sum( S[x==1] ) )



# No constraints
check_constraints= None




###################
# Solution with brute force
###################


# Problem formulation
S= np.array( [1, 2, 3, 4, 5, 6] , dtype=int)
n= len(S) # Number of nodes (variables)
D= [ list(range(2)) ]*n # Domains


# Cost function as a lambda to adapt the f function to the solver's format
cost_f= lambda x: f(x, S)


# Calculation of the solution
x= exact_optimizer(n, D, check_constraints, cost_f)

print('The brute force algorithm returned the solution x={} with cost f(x)={}'.format(x, cost_f(x)))




###################
# Solution with simulated annealing
###################

x_init= np.zeros(n, dtype=int) # Initial solution

# Algorithm parameters
T_init= 60 # Initial temperature
T_factor= 0.9 # Cooling factor
max_iter= 30

# Call to the optimization algorithm
x= SA_optimizer(x_init, cost_f, neighbour_generator, T_init, T_factor, max_iter)


# Show solution 
print('The simulated annealing algorithm returned the solution x={} with cost f(x)={}'.format(x, cost_f(x)))