"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import sys
from qiskit.quantum_info import SparsePauliOp, Statevector
import numpy as np

# We check if we can build the operator
try:
    oper = SparsePauliOp.from_list([("X", 0.5), ("Z", 0.5)]).to_operator()
except:
    print('Cannot build the operator 0.5X+0.5Z')
    sys.exit(0)

# Check if it is hermitian
hermit = np.allclose( oper.to_matrix(), oper.to_matrix().conjugate().T)
if hermit:
    print('It is an observable')
else:
    print('It IS NOT an observable')
    sys.exit(0)

# Expected value
sv = Statevector.from_label('0')
print('Expected value of the observable: ', sv.expectation_value(oper))
    