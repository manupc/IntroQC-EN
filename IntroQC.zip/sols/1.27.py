"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Definitions 

# Define matrices H, Z and Identity (I)
H = (1 / np.sqrt(2)) * np.array([[1, 1], [1, -1]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
I = np.eye(2, dtype=complex)

# Define the basis vectors |0> and |1>
ket_0 = np.array([1, 0], dtype=complex)
ket_1 = np.array([0, 1], dtype=complex)


# Preparation of vectors and operators 

# Create the vector |01> = |0> ⊗ |1> using the Kronecker (tensor) product
ket_01 = np.kron(ket_0, ket_1)
bra_01 = ket_01.conj().T


# Calculations

# a) <01|(Z ⊗ I)|01>
op_a = np.kron(Z, I)
res_a = bra_01 @ op_a @ ket_01

# b) <01|(I ⊗ Z)|01>
op_b = np.kron(I, Z)
res_b = bra_01 @ op_b @ ket_01

# c) <01|(Z ⊗ Z)|01>
op_c = np.kron(Z, Z)
res_c = bra_01 @ op_c @ ket_01

# d) (H|0>) ⊗ (Z|1>)
vec_d1 = H @ ket_0
vec_d2 = Z @ ket_1
res_d = np.kron(vec_d1, vec_d2)


# Show Results
print("a) <01|(Z ⊗ I)|01> = {:.1f}".format(res_a))
print("b) <01|(I ⊗ Z)|01> = {:.1f}".format(res_b))
print("c) <01|(Z ⊗ Z)|01> = {:.1f}".format(res_c))
print("d) (H|0>) ⊗ (Z|1>) = {}".format(np.round(res_d, decimals=5)))