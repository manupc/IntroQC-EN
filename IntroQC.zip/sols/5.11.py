"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, Pauli


qc= QuantumCircuit(2)
qc.x(1)
qc.save_statevector()


sim= AerSimulator()
n_shots= 1
sv= sim.run(transpile(qc, sim), shots=n_shots).result().get_statevector()

ZI= Pauli('ZI'[::-1]) # move to little endian
IZ= Pauli('IZ'[::-1]) # move to little endian
ZZ= Pauli('ZZ') 

print('<01|>ZI|01>= {}, because the eigenvalue of |0> is 1 in Z'.format(sv.expectation_value(ZI)))
print('<01|>IZ|01>= {}, because the eigenvalue of |1> is -1 in Z'.format(sv.expectation_value(IZ)))
print('<01|>ZZ|01>= {}, because the eigenvalue of |01> is -1 in ZZ'.format(sv.expectation_value(ZZ)))
