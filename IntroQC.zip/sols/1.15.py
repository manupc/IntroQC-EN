"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Transformation matrix T from the previous exercise
T = np.array([[3, -1],
              [2, 5]])

# Original vector v from the previous exercise
v = np.array([5, 2])

# Transformed vector v_prima from the previous exercise (T @ v)
# We ensure v_prima is calculated here in case this script is run independently
vp = T @ v

print("Original vector (v): {}".format(v))
print("Transformation matrix (T):\n", T)
print("\nTransformed vector (v'): {}".format(vp))

# Calculate the inverse of T 
try:
    Tinv = np.linalg.inv(T)
    print("\nInverse matrix of T (T^(-1)):\n", Tinv)

    # Apply the inverse transformation to vp
    vr = Tinv @ vp
    print("\nRecovered vector (vr): {}".format(vr))

    # Check if the recovered vector is the original one
    if np.allclose(v, vr):
        print("\nThe original vector was recovered correctly.")
    else:
        print("\nThe original vector was NOT recovered exactly. There might be precision issues.")

except:
    print("\nError: The matrix T is not invertible (its determinant is zero).")