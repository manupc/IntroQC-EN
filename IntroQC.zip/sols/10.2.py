"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit import QuantumRegister, ClassicalRegister
import numpy as np
from qiskit_aer import AerSimulator
from qiskit.circuit.library import phase_estimation, ZGate

# length of the estimation register
n= 2

# Executions
n_shots= 1000

for state in ['0', '1']:
    

    # Circuit creation
    b= QuantumRegister(size=n, name='qb')
    cb= ClassicalRegister(size=n, name='cb')
    psi= QuantumRegister(size=1, name='qpsi')

    qc= QuantumCircuit(b, psi, cb)
    
    if state =='1':
        qc.x(psi[0])
    
    QPE= phase_estimation(num_evaluation_qubits= n, unitary= ZGate())
    qc.append(QPE, b[:]+psi[:])

    # Swap qubits from little endian to big endian
    middle= n//2
    for k in range(middle):
        qc.swap(b[k], b[n-k-1])
    
    qc.measure(b, cb)
    
    # Simulation
    sim= AerSimulator()
    counts= sim.run(transpile(qc, sim), shots= n_shots).result().get_counts()
    
    
    ket= list(counts.keys())[0] # We get the output ket
    bintheta= 0
    for k in range(len(ket)):
        bk= int(ket[k])
        bintheta+= bk*(2**(-k-1))
    theta= 2*np.pi*bintheta
    # Phase estimation of state |{}>: {}
    print('Phase estimation of state |{}>: {}'.format(state, theta))