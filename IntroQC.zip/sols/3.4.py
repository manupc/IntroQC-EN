"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator

# Circuit 1 generation
qc1= QuantumCircuit(1)
qc1.h(0)
qc1.s(0) 
qc1.save_unitary()

# Circuit 2 generation
qc2= QuantumCircuit(1)
qc2.sxdg(0)
qc2.save_unitary()




sim= AerSimulator(method='unitary')
U1= sim.run(transpile(qc1), shots= 1).result().get_unitary()
U2= sim.run(transpile(qc2), shots= 1).result().get_unitary()

print('They are equivalent: ', U1.equiv(U2))
print('The unitary matrix of circuit SH|0> is:\n', U1)
print('The unitary matrix of circuit sqrt(X)^dg|0> is:\n', U2)


