"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the original vector in the canonical basis
v = np.array([2, -3])
print("Original vector v (in canonical basis): {}".format(v))

# Define the vectors of the new basis B
b1 = np.array([1, 2])
b2 = np.array([3, 1])
print("\nVectors of the new basis B:")
print("\tb1: {}".format(b1))
print("\tb2: {}".format(b2))

# Build the change of basis matrix P_B_to_E
P_B_to_E = np.array([b1, b2]).T # .T transposes so that b1 and b2 are columns
print("\nChange of basis matrix P_B_to_E (from B to E):\n{}".format(P_B_to_E))

# Calculate the inverse of P_B_to_E to get P_E_to_B
try:
    P_E_to_B = np.linalg.inv(P_B_to_E)
    print("\nChange of basis matrix P_E_to_B (from E to B, inverse of P_B_to_E):\n{}".format(P_E_to_B))

    # Calculate the coordinates of vector v in the new basis B
    vp = P_E_to_B @ v
    print("\nCoordinates of vector v in the new basis B (v'): {}".format(vp))

except:
    print("\nError: The matrix P_B_to_E is not invertible. The basis vectors B might not be linearly independent.")