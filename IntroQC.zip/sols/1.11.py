"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the vectors
v = np.array([0.6, 0.8])
w = np.array([-0.8, 0.6])
y = np.array([1, 1])

# Print the dot products and determine orthogonality
print("Vector v: {}".format(v))
print("Vector w: {}".format(w))
print("Vector y: {}".format(y))

# Calculate the dot products
dot_vw = np.dot(v, w)
dot_vy = np.dot(v, y)
dot_wy = np.dot(w, y)


# Check orthogonality
print("\nOrthogonality Check:")

# Definition of tolerance for comparison with zero
tolerancia = 1e-9 

if np.isclose(dot_vw, 0, atol=tolerancia):
    print("\tv and w ARE orthogonal (dot product = {})".format(dot_vw))
else:
    print("\tv and w ARE NOT orthogonal (dot product = {})".format(dot_vw))

if np.isclose(dot_vy, 0, atol=tolerancia):
    print("\tv and y ARE orthogonal (dot product = {})".format(dot_vy))
else:
    print("\tv and y ARE NOT orthogonal (dot product = {})".format(dot_vy))

if np.isclose(dot_wy, 0, atol=tolerancia):
    print("\tw and y ARE orthogonal (dot product = {})".format(dot_wy))
else:
    print("\tw and y ARE NOT orthogonal (dot product = {})".format(dot_wy))