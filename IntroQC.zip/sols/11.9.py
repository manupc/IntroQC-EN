"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import re
import numpy as np
from itertools import product
from pyqubo import Array
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit.quantum_info import SparsePauliOp
from qiskit import transpile
from qiskit_aer import AerSimulator
from scipy.optimize import minimize


####################################
# From OptimizationTools.py
####################################

# For a PyQUBO Array z, the function generates a dictionary 
# with variable names (key) and a unique index (integer value)
def getVarIndices(z : Array):
    
    # We get all the indices of the solutions in z
    indices= [list(range(i)) for i in z.shape]
    z_idx= list(product(*indices)) 
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    var_ind= {} # Generate dictionary (variable name : integer index)
    for i, ind in enumerate(z_idx):
        
        # Remove prefix Spin(' and postfix ')
        name= str(z[tuple(ind.tolist())])[6:-2]
        var_ind[name]= i # Assign variable name to index
    return var_ind




# Transforms an Ising model into a sequence of Pauli operators
def IsingToPauli(z, ising, show=False, to_little_endian= False):
    
    var_idx= getVarIndices(z) # Assign each variable in z to an integer index
    n= np.prod(z.shape) # Number of required qubits
    
    seq= [] # Sequence of Pauli operators
    for ising_elm in ising:
        if not isinstance(ising_elm, float): # We omit the independent term
            for ZiZj in ising_elm: # Iterate over variables Zi or ZiZj
                
                # Create str representation of ID operations on each qubit
                pauli_tensor= ['I']*n 
                
                # Get variables Zi or ZiZj involved in the ZiZj term
                var= (ZiZj,) if not isinstance(ZiZj, tuple) else ZiZj
                for zi in var: # Iterate over them
                    idx= var_idx[zi] # Get the index assigned to the variable
                    pauli_tensor[idx]= 'Z' # Apply Z operation on the variable's qubit
                coef= ising_elm[ZiZj] # Get multiplier coefficient Jij * ZiZj
                
                # Convert pauli_tensor list to string
                str_pauli= ''.join(var for var in pauli_tensor)
                if to_little_endian:
                    str_pauli= str_pauli[::-1]
                
                # Insert the pair (str_pauli, coef) into the sequence of Pauli operators
                seq.append( (str_pauli, coef) )
    if show:
        print('List of Pauli operators for H_P: {}'.format(seq))
    return SparsePauliOp.from_list(seq) # return seq as a sequence of Pauli operators


# For a binary solution x=(x0, x1, ...) where xi has values 0/1, and given
# a sequence of Pauli operators H_P, the function returns the energy of the solution
def energy_classic(x: np.ndarray, H_P : SparsePauliOp):
    
    z_spin= (2*x-1) # Move x to the set {-1, 1}
    Hz= 0 # Evaluate H(z) initialized to 0
    for pauli_op in H_P: # Iterate over all Pauli operators
    
        # Get the coefficient associated with the Pauli operator (real number)
        coef= float(pauli_op.coeffs.squeeze().real)
        
        # Get the string with the representation of the gates that make up the operator
        gates= str( pauli_op.paulis[0] )
        
        # Get the list of positions where the Z gate is located
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Look for the positions of the Z operator
            Zlist.append(z_pos.start())
        
        # Update energy function
        Hz+= coef*np.prod(z_spin[ Zlist ])
    return Hz


# Calculates the expectation value of <x|H_P|x> from
# the measurements given in counts by the circuit execution
def ExpVal_from_counts(counts : dict, H_P: SparsePauliOp, reverse_ket= False):
    N= 0
    expval= 0
    for ket in counts:
        num_meas= counts[ket]
        N+= num_meas
        ket_rev= ket[::-1] if reverse_ket else ket
        ket_arr= np.array([int(xi) for xi in ket_rev])
        fx= energy_classic(ket_arr, H_P)
        expval+= fx*num_meas
    return expval/N


# Prepares the execution of an optimization circuit
# qaoa_circ with params parameter values for gamma and beta,
# using the sim simulator with shots circuit executions
# Returns the expectation value of the observable implemented in qaoa_circ
def run_circuit_expectation(params, qaoa_circ, sim, shots, H_P, reverse_ket= False):
    qc= qaoa_circ.assign_parameters(params)
    counts= sim.run(transpile(qc, sim), shots= shots).result().get_counts()
    return ExpVal_from_counts(counts, H_P, reverse_ket)



# Gets the best (most probable) solution to a problem
# given the measurements taken in counts
def getBestSolution(counts, to_big_endian= True):
    maxVal= 0
    bestket= None
    for ket in counts: # Look for the ket with the highest measurement probability
        if counts[ket] > maxVal:
            maxVal= counts[ket]
            bestket= ket
    return bestket[::-1] if to_big_endian else bestket


# Construction of the exponential circuit of the Ising model
# with parameter t
def ProblemCircuit(pauli : SparsePauliOp, t : float, reverse_ops : bool= False):
    
    # Generate circuit
    n_qubits= pauli.num_qubits
    qc_problem= QuantumCircuit(n_qubits)
    
    # Iterate over each pauli operator    
    for oper in pauli:
        
        # Get coefficient 
        coef= float(oper.coeffs.squeeze().real) 
        
        # Get the pauli matrices as a string
        gates= str(oper.paulis[0])[::-1] if reverse_ops else str(oper.paulis[0])
        
        # Get positions of the qubits where Z gates are applied
        # Get list with the positions where the Z gate is located
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Look for the positions of the Z operator
            Zlist.append(z_pos.start())
            
        if len(Zlist)==1: # Single Rz operation on one qubit
            qc_problem.rz(2*coef*t, Zlist[0])
        else: # Rzz operation on two qubits
            qc_problem.rzz(2*coef*t, Zlist[0], Zlist[1])
        
    return qc_problem


# Creation of the QAOA Mixer circuit with parameter beta
def MixerCircuit(n_qubits, beta):
    qc_mixer= QuantumCircuit(n_qubits) # Circuit creation
    qc_mixer.rx(2*beta, range(n_qubits)) # Inclusion of parameterized Rx gates
    return qc_mixer


# Construction of the QAOA circuit for the ising problem given by the 
#  sequence of pauli operators with L layers
def QAOAcirc(L : int, pauli : SparsePauliOp):
    
    # Generation of gamma/beta parameters
    n_qubits= pauli.num_qubits
    gamma= ParameterVector(length= L, name='gamma')
    beta= ParameterVector(length= L, name= 'beta')
    
    # Circuit creation: superposition 
    qc= QuantumCircuit(n_qubits)
    qc.h(range(n_qubits))
    
    # L layers of hamiltonian+mixer
    for l in range(L):
        qc= qc.compose(ProblemCircuit(pauli, gamma[l]))
        qc= qc.compose(MixerCircuit(n_qubits, beta[l]))
    qc.measure_all()
    return gamma, beta, qc

####################################
# Solution
####################################



# Problem generation
n=6
S= np.array([1, 2, 3, 4, 5, 6], dtype= int)
n= len(S)
print('Initial problem representation:')
print(S)


# Creation of variables for the Ising model
z = Array.create('z', shape=(n,), vartype='SPIN')

# Problem coefficients and formulation
Ising= 0 # Ising model

# Cost function formulation
for i in range(len(S)):
    # QUBO Model: S[i]*z[i] adds S[i] when z[i]=1 and subtracts it when z[i]=-1
    Ising+= S[i]*z[i]
Ising= Ising**2 # Squared so that the difference is positive

model= Ising.compile()
ising= model.to_ising()

print('\nIsing Model:')
for coefs in ising:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])


# Transformation from Ising model to a sequence of Pauli operators
pauli= IsingToPauli(z, ising, to_little_endian= False)

# Creation of the QAOA circuit with L layers and shots measurements
L= 1
shots= 2048
gamma, beta, qaoa_circ= QAOAcirc(L, pauli)

# Preparation of the simulator and the function to be optimized
sim= AerSimulator()
to_be_minimized= lambda params : run_circuit_expectation(params, qaoa_circ, sim, shots, pauli)


# Initial parameters for beta and gamma
params_init= np.zeros(2*L) #np.random.rand(2*L) 

# Optimization of gamma and beta with COBYLA
params = minimize(to_be_minimized,
               params_init,
               method='COBYLA').x

print('\nBest parameters: {}'.format(params))

# Execution of the QAOA circuit with the best parameters
res_circ= qaoa_circ.assign_parameters(params)
counts = sim.run(transpile(res_circ, sim), shots= shots).result().get_counts()


# Obtaining the best solution
solution_bin= getBestSolution(counts)
x= np.array([int(xi) for xi in solution_bin])
cost= energy_classic(x, pauli)

print('Best solution found (binary): {} with energy cost={}'.format(x, cost))