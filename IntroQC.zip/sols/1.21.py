"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Define the matrix H
H = (1 / np.sqrt(2)) * np.array([
    [1, 1],
    [1, -1]
])

# Calculate the conjugate transpose (Hermitian adjoint) of H
H_dagger = np.conjugate(H).T

# Multiply the adjoint by the original matrix
prod = H_dagger @ H

# Check if the result is the identity matrix
I = np.identity(2)
unitary = np.allclose(prod, I)

# Show the results
print("Matrix H:\n", H)
print("\nProduct H† * H:\n", prod)

if unitary:
    print("The matrix H is unitary.")
else:
    print("The matrix H IS NOT unitary.")