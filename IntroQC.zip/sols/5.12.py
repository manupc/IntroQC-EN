"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector, Pauli
import numpy as np


ZZ= Pauli('ZZ')
lst= ['00', '01', '10', '11']

sim= AerSimulator(method='statevector')
for st in lst:
    sv0= Statevector.from_label(st)
    qc= QuantumCircuit(2)
    qc.initialize(sv0)
    qc.rzz(np.pi/2, 0, 1)
    qc.save_statevector()
    svc= sim.run(transpile(qc, sim), shots=1).result().get_statevector()
    exp= svc.expectation_value(ZZ)
    print('<{}|ZZ|{}>= {}'.format(st, st, exp))
    


