"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np

# Quantum circuit
n= 3
qc= QuantumCircuit(n)
qc.h(0) # Creating entanglement (|00>+|11>)/sqrt(2))
for i in range(1, n):
    qc.cx(0,i)
qc.h(range(n)) # Creating entanglement (|++>+|-->)/sqrt(2))

# Measure in Hadamard
qc.h(range(n))
qc.save_statevector()

sim= AerSimulator()
sv= sim.run(transpile(qc, sim), shots=1).result().get_statevector()

svd= sv.to_dict()
for k in svd:
    if not np.isclose(svd[k], 0):
        print('{}: {}'.format(k[::-1], svd[k]))