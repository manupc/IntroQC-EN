"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Problem generation
S= np.array([1, 2, 3, 4, 5, 6], dtype= int)

# Initial problem representation:
print('Initial problem representation:')
print(S)

# Creation of variables for the QUBO model
x = Array.create('x', shape=(len(S),), vartype='BINARY')

# QUBO problem coefficients matrix and formulation
Q= 0 # QUBO Model

# Cost function formulation
for i in range(len(S)):
    # QUBO Model: (2*x[i]-1)*S[i] adds S[i] when x[i]=1 and subtracts when x[i]=0
    Q+= (2*x[i]-1)*S[i]
Q= Q**2 # Squared so that the difference is positive


# Create theoretical QUBO model
model= Q.compile()
qubo, offset= model.to_qubo()
# QUBO Model:
print('\nQUBO Model:')
for key in qubo:
    print(key, qubo[key])

# Create binary quadratic model (BQM)
bqm= model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
# The {} solutions obtained: 
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Obtaining the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars= best_sample.sample
best_sample_cost= best_sample.energy

solution = np.zeros(len(S), dtype=int)
for var in best_sample_vars:
    for i, x_i in enumerate(x):
        if var in str(x_i):
            solution[i] = best_sample_vars[var]
    
# Best Solution: x={} with cost f(x)={}
print('\nBest Solution: x={} con coste f(x)={}'.format(solution, best_sample_cost))