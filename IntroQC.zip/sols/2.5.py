"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generation of the states
ls = [
     Statevector([-1, 0]),
     Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([-1/np.sqrt(2), 1/np.sqrt(2)]),
     Statevector([1, 0]),
     Statevector([1j/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1j/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1/np.sqrt(2)]),
     ]

# We iterate over all of them
for i, sv1 in enumerate(ls):
    for j, sv2 in enumerate(ls):
        if j > i:
            equiv = sv1.equiv(sv2)
            if equiv:
                # |psi_{}> and |psi_{}> are equivalent.
                print('|psi_{}> and |psi_{}> are equivalent.'.format(i+1, j+1))