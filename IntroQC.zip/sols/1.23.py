"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from scipy.linalg import expm

# Define the matrix Y from the previous exercise
Y = np.array([
    [0, -1j],
    [1j,  0]
])

# Build the exponent matrix: (i * pi/2 * Y)
M = 1j * (np.pi / 2) * Y

# Calculate the matrix U = exp(exponent_matrix) using SciPy
U = expm(M)

# Check if the resulting matrix U is unitary
U_dagger = np.conjugate(U).T
prod = U_dagger @ U
I = np.identity(2)
unitary = np.allclose(prod, I)

# 5. Show the results
print("Matrix Y:\n", Y)
print("\nMatrix U = exp(i * pi/2 * Y):\n", np.round(U, decimals=5))
print("\nProduct U† * U:\n", np.round(prod, decimals=5))

if unitary:
    print("The resulting matrix U is unitary.")
else:
    print("The resulting matrix U IS NOT unitary.")