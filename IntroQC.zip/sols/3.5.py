"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.circuit.library import YGate
from qiskit.quantum_info import Operator

# Circuit generation
qc1= QuantumCircuit(1)
qc1.s(0)
qc1.h(0)
qc1.s(0) 
qc1.x(0) 
qc1.h(0)
qc1.save_unitary()

Y= Operator(YGate())

sim= AerSimulator(method='unitary')
U1= sim.run(transpile(qc1), shots= 1).result().get_unitary()
print("The circuit's unitary matrix is:\n", U1)
print('They are equivalent: ', Y.equiv(U1))

