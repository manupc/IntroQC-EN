"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.quantum_info import Statevector

# Generation of the states
ls = [
     Statevector([-1, 0]),
     Statevector([1/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([-1/np.sqrt(2), 1/np.sqrt(2)]),
     Statevector([1, 0]),
     Statevector([1j/np.sqrt(2), -1/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1j/np.sqrt(2)]),
     Statevector([1/np.sqrt(2), 1/np.sqrt(2)]),
     ]

# We iterate over all of them
for i, sv in enumerate(ls):

    # Get numpy representation
    np_rep = sv.data

    # Initialize strings for representations
    txtbin, txtmp, txttri = '', '', ''
    # Binomial form
    txtbin = '{}'.format(np_rep[0])+'|0>  + '+'{}'.format(np_rep[1])+'|1>'
        
    # polar form of each amplitude
    mag0, ang0 = np.abs(np_rep[0]), np.angle(np_rep[0])
    mag1, ang1 = np.abs(np_rep[1]), np.angle(np_rep[1])

    txtmp = '{}e^({}i)'.format(mag0, ang0)+'|0> + '+'{}e^({}i)'.format(mag1, ang1)+'|1>' 
        
    # Trigonometric
    phi = 2*np.arccos(mag0)
    theta = ang1-ang0
    txttri = 'cos({}/2)'.format(phi)+'|0> + '+'sin({}/2)e^({}i)'.format(phi, theta)+'|1>' 

    # Show results
    print('-'*10)        
    print('\tBinomial form: '+txtbin)
    print('\tMagnitude and phase form: '+txtmp)
    print('\tTrigonometric form: '+txttri)
    
    
