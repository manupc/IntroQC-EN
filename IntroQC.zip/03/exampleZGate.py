"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import ZGate, YGate
from qiskit.quantum_info import Statevector

# We create the state |+> and display it
sv = Statevector.from_label('+')
print('Initial state |+>: {}'.format(sv))


# We create the gates
Y, Z = YGate(), ZGate()

# We apply the gate on the state
Zsv = sv.evolve(Z)
print('Intermediate state Z|+> : {}'.format(Zsv))

# We apply the Y gate on the result
YZsv = Zsv.evolve(Y)
print('Final state YZ|+> : {}'.format(YZsv))


# We create the state |i> and display it
sv = Statevector.from_label('r')
print('Initial state |i> : {}'.format(sv))

# We apply the gate on the state
Zsv = sv.evolve(Z)

# We transform the result to a Statevector and display it
print('Final state Z|i> : {}'.format(Zsv))