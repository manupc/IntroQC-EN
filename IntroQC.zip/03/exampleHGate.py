"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import ZGate, HGate
from qiskit.quantum_info import Statevector
import numpy as np

# We create the state |0> and display it
sv = Statevector.from_label('0')
print('Initial state |0>: {}'.format(sv))

# We create the gates
Z, H = ZGate(), HGate()

# We apply the gate on the state
Hsv = sv.evolve(H)
print('Intermediate state H|0> : {}'.format(Hsv))

# We apply the Z gate on the result
ZHsv = Hsv.evolve(Z)
print('Intermediate state ZH|0> : {}'.format(ZHsv))

# We apply the H gate on the result
HZHsv = ZHsv.evolve(H)
print('Final state HZH|0> : {}'.format(HZHsv))


# We create the state |psi>= cos(pi/8)|0> + sin(pi/8)|1> and display it
alpha0 = np.cos(np.pi/8)
alpha1 = np.sin(np.pi/8)
sv = Statevector([alpha0, alpha1])
print('Initial state |q> : {}'.format(sv))


# We apply the gate on the state
Hsv = sv.evolve(H)
print('Final state H|q> : {}'.format(Hsv))