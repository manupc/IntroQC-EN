"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.circuit.library import IGate
from qiskit.quantum_info import Statevector

# We instantiate the I gate
I_gate = IGate()

# Display object information 
print('Quantum I gate:')
print(I_gate)

# Display unitary matrix information
U = I_gate.to_matrix()
print('\nUnitary matrix U:', type(U))
print(U)

# Get adjoint (inverse)
UT = I_gate.inverse().to_matrix()
print('\nAdjoint matrix UT:', type(UT))
print(UT)

# Creation of quantum state |0> in NumPy
psi = Statevector.from_label('0').data
print('\n|psi>:')
print(psi)

# Simulation of state evolution
psi_prime = U @ psi.reshape(-1, 1)
print('\nI|psi>:')
print(psi_prime.squeeze())