"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from IPython.display import display

qc = QuantumCircuit(1)
qc.h(0)
qc.z(0)
qc.h(0)

# Save the statevector before measurement
qc.save_statevector()

# Initial circuit:
display(qc.draw('mpl'))

# Instantiation of the Aer simulator
simulator = AerSimulator(method='statevector')

# Rewrite circuit to meet the conditions of the device
# where it will be executed
qct = transpile(qc, simulator)
# Circuit after transpile:
display(qct.draw('mpl'))

# Run the circuit simulation
job = simulator.run(qct, shots=1)
result = job.result()

# Get the statevector before measurement
sv = result.get_statevector(qct)
print('\nSimulated Statevector:')
print(sv)
