"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit
from qiskit.circuit.library import XGate, YGate
from IPython.display import display
       
qc1= QuantumCircuit(1, 1) # Circuit with 1 qubit
qc2= QuantumCircuit(1, 1) # Circuit with 1 qubit

qc1.append(XGate(), [0]) # X gate on qubit 0
qc1.append(YGate(), [0]) # Y gate onqubit 0
qc2.measure(0,0) # Measurement of all qubits

# First circuit:
display( qc1.draw('mpl') )

# Second circuit:
display( qc2.draw('mpl') )


qc= qc1.compose(qc2)
# Composition of first and second circuits
display( qc.draw('mpl') )