"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector

## Example of using SX
qc = QuantumCircuit(1)
qc.sx(0)

# We save the circuit's statevector
qc.save_statevector()


# Instantiation of the Aer simulator
simulator = AerSimulator(method='statevector')

# Rewrite circuit to meet the device's conditions
# where it will be executed
qct = transpile(qc, simulator)

# Run the simulation
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResult of applying SX|0>:', sv)
print('|-i> :', Statevector.from_label('l'))



## Example of using SXdg
qc = QuantumCircuit(1)
qc.sxdg(0)

# We save the circuit's statevector
qc.save_statevector()

# Rewrite circuit to meet the device's conditions
# where it will be executed
qct = transpile(qc, simulator)

# Run the simulation
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResult of applying SXdg|0>:', sv)
print('|i> :', Statevector.from_label('r'))