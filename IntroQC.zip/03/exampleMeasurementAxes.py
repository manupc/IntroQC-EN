"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np
from IPython.display import display
tol = 0.05 # Error tolerance

# State we want to model
phi, theta = np.pi/4, -np.pi/4
sv_target = Statevector([np.cos(phi/2), np.sin(phi/2)*np.exp(1.j*theta)])

# State preparation circuit
qc_prep = QuantumCircuit(1,1)
qc_prep.sx(0)
qc_prep.t(0)
qc_prep.sxdg(0)
qc_prep.tdg(0)
qc_prep.save_statevector()

# Simulate the state we want to prepare
sim = AerSimulator()
sv_prep = sim.run(transpile(qc_prep, sim), shots=1).result().get_statevector()


print('The desired state:    {}'.format(sv_target))
print('The prepared state: {}'.format(sv_prep))


# Circuits for measurement in the three axes
shots = 100000 # Number of measurements to perform
qc_measZ = QuantumCircuit(1,1) # Measurement in Z
qc_measZ.measure(0,0)

qc_measX = QuantumCircuit(1,1) # Measurement in X
qc_measX.h(0)
qc_measX.measure(0,0)

qc_measY = QuantumCircuit(1,1) # Measurement in Y
qc_measY.sdg(0)
qc_measY.h(0)
qc_measY.measure(0,0)


# Measure counts on the Z axis
qc = qc_prep.compose( qc_measZ )

display(qc.draw('mpl')) # Z measurement circuit

counts = sim.run(qc, shots=shots).result().get_counts()
print('Measurements in Z: {}'.format(counts))
countsKet0 = counts['0'] / shots

# Measure counts on the X axis
qc = qc_prep.compose( qc_measX )

display(qc.draw('mpl')) # X measurement circuit

counts = sim.run(qc, shots=shots).result().get_counts()
print('Measurements in X: {}'.format(counts))
countsKetPlus = counts['0'] / shots
countsX_diff = (counts['0'] - counts['1'])/shots

# Measure counts on the Y axis
qc = qc_prep.compose( qc_measY )

display(qc.draw('mpl')) # Y measurement circuit

counts = sim.run(qc, shots=shots).result().get_counts()
print('Measurements in Y: {}'.format(counts))
countsKetI = counts['0'] / shots
countsY_diff = (counts['0'] - counts['1'])/shots


# Approximate in which quadrant of the sphere the vector is
if 0.5 - tol <= countsKet0 <= 0.5 + tol: # on the Z axis
    print('The qubit is on the Z equator')
elif countsKet0 < 0.5 - tol:
    print('The qubit is in the Z southern hemisphere')
else:
    print('The qubit is in the Z northern hemisphere')


if 0.5 - tol <= countsKetPlus <= 0.5 + tol: # on the X axis
    print('The qubit is on the X equator')
elif countsKetPlus > 0.5 + tol:
    print('The qubit is in the X front')
else:
    print('The qubit is in the X back')


if 0.5 - tol <= countsKetI <= 0.5 + tol: # on the Y axis
    print('The qubit is on the Y equator')
elif countsKetI > 0.5 + tol:
    print('The qubit is on the Y right')
else:
    print('The qubit is on the Y left')

phi_aprox = 2 * np.arccos( np.sqrt(countsKet0) )
print('real phi={:.3f} and aprox={:.3f}'.format(phi, phi_aprox))


# If countsY_diff ~= 0 and countsX_diff ~= 0, it's ket |0> or |1>
if -tol <= countsX_diff < tol and -tol <= countsY_diff < tol:
    theta_aprox = 0
else:
    theta_aprox = np.arctan2(countsY_diff, countsX_diff)
print('real theta={:.3f} and aprox theta={:.3f}'.format(theta, theta_aprox))

alpha0 = np.cos(phi_aprox/2)
alpha1 = np.sin(phi_aprox)/2*np.exp(1.j*theta_aprox)
sv_resul = Statevector([alpha0, alpha1])
print('Simulated state to approximate: {}'.format( sv_prep ))
print('Reconstructed state: {}'.format(sv_resul))



