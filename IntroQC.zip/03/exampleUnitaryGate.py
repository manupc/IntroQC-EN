"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit.circuit.library import UnitaryGate
from qiskit.quantum_info import Statevector

Xmatrix = np.array([[0, 1],
                    [1, 0]], dtype=complex)

Xgate = UnitaryGate(Xmatrix, label='NOT')

# Display information about the UnitaryGate object
print('Quantum NOT gate:')
print(Xgate)

# Display information about the unitary matrix
U = Xgate.params[0]
print('\nUnitary U:', type(U))
print(U)

# Get adjoint
UT = Xgate.adjoint().params[0]
print('\nUnitary Adjoint UT:', type(UT))
print(UT)

# Verification of unitary matrix
print('\nU @ UT:')
print(U @ UT)

# Creation of quantum state |0> in NumPy
psi = Statevector.from_label('0').data

# Simulation of state evolution
psi_prime = U @ psi.reshape(-1, 1)
print('\nNOT|psi>:')
print(psi_prime.squeeze())