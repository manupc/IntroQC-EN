"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

N= 10000 # Number of samples (times to flip a coin. Value 0= heads; 1= tails
results= np.zeros(2, dtype=int) # Store the number of heads and tails


# flip a coin using rand
samples= np.random.rand(N) < 0.5 # assume p(heads)= p(tails)= 0.5
results[0]= np.sum(samples==0) # Count number of heads
results[1]= np.sum(samples==1) # Count number of tails

print("\nUsing rand(size):")
print('We observed heads {} times among {} flips'.format(results[0], N))
print('We observed tails {} times among {} flips'.format(results[1], N))


# flip a coin with randint
samples= np.random.randint(low=0, high=2, size=N)
results[0]= np.sum(samples==0)
results[1]= np.sum(samples==1)

print("\nUsing randint(low, high, size):")
print('We observed heads {} times among {} flips'.format(results[0], N))
print('We observed tails {} times among {} flips'.format(results[1], N))


# Random sort of numbers from 0 to 9 (random permutation)
perm= np.random.choice(a= range(10), size=10, replace=False)
print('10 elements at random order: {}'.format(perm))

