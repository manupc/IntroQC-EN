"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

M= np.array([ [1, 0],
              [0, -1]
            ])

eigval, eigvec= np.linalg.eig(M)

print('Matrix M:')
print(M)

for i, (u, lmbda) in enumerate(zip(eigvec.T, eigval)):
    
    u= u.reshape(-1, 1)
    print('\nEigenvector u_{}={} with eigenvalue lambda_{}= {}'.format(i, u, i, lmbda))
    print('\tMultiplication of M@u_{}:\n{}'.format(i, M@u))
    print(  )
    print('\tMultiplication of lambda_{}*u_{}:'.format(i, i))
    print(lmbda*u)
    
