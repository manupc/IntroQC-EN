"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from math import sqrt

c1= 1+2.j # Complex number with real part 1 and imaginary part 2
c2= -1.j # Complex number with real part 0 and imaginary part -1

print('Addition {} + {} = {}'.format(c1, c2, c1+c2))
print('Multiplication {} * {} = {}'.format(c1, c2, c1*c2))
print('Re({})= {}   ; Im({})= {}'.format(c1, c1.real, c1, c1.imag))
print('Conjugate of {} = {}'.format(c1, c1.conjugate()))
print('Multiplication {} * {} = {}'.format(c1, c1.conjugate(), c1*c1.conjugate()))
print('|{}| = {}'.format(c1, abs(c1)))
print('|{}| (manually)= {}'.format(c1, sqrt(c1.real**2 + c1.imag**2)))
