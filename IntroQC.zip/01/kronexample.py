"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

B_V= [ [1, 0], 
       [0, 1] ]

B_W= [ [1, 0, 0],
       [0, 1, 0], 
       [0, 0, 1]]


i= 0
for e_V in B_V:
    for e_W in B_W:
        e_tensor= np.kron(e_V, e_W)
        i= i+1
        print('e_{} in B tensor W: {}'.format(i, e_tensor))

    
