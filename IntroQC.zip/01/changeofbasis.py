"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display


theta= np.pi/4 # Rotation angle
B= np.array([ [np.cos(theta), -np.sin(theta)], # Matrix of Change of basis
              [np.sin(theta), np.cos(theta)]
            ] )

e1= np.array([[1], # Vector e1 of canonical basis
              [0]])

e2= np.array([[0], # Vector e2 of canonical basis
              [1]])

p1= B@e1 # change of basis for e1
p2= B@e2 # change of basis for e2

# Plot results in a picture
x_init= [0, 0]
y_init= [0, 0]
x_end= [e1[0, 0], e2[0, 0]]
y_end= [e1[1, 0], e2[1, 0]]

f= plt.figure(figsize=(7.5,5))
plt.grid(linestyle='dashed')
plt.rc('axes', axisbelow=True)
plt.xlim([-1.5, 1.5])
plt.ylim([-0.5, 1.5])
plt.quiver(x_init, y_init, x_end, y_end,
           scale_units='xy', angles = 'xy', units='xy', scale=1, color='black')
plt.show()
display(f)

x_end= [p1[0, 0], p2[0, 0]]
y_end= [p1[1, 0], p2[1, 0]]
plt.quiver(x_init, y_init, x_end, y_end,
           scale_units='xy', angles = 'xy', units='xy', scale=1, color='gray')
plt.show()
display(f)
