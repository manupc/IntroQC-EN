"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np


D34= np.eye(3, 4) # Diagonal matrix of 1's, size=3x4
Z33= np.zeros( (3, 3) ) # Zero-matrix of size 3x3
O42= np.ones( (4, 2) ) # One-matrix of size 4x3

# Matrix of size 2 rows and 4 columns
M= np.array( [ [1, 2, 3, 4], # Row 1
               [5, 6, 7, 8] # Row 2
            ] )

print('Variable D34. Size: {}'.format(D34.shape))
print(D34)

print('Variable Z33. Size: {}'.format(Z33.shape))
print(Z33)

print('Variable O42. Size: {}'.format(O42.shape))
print(O42)

print('Variable M. Size: {}'.format(M.shape))
print(M)

print('Transpose Matrix of M. Size: {}'.format(M.T.shape))
print(M.T)

M2= O42 + M.T # Addition of M.T + O42
print('M2. Addition M.T + O42:')
print(M2)

M3= 2*D34@M2 # Multiplication o (2*D34)@M2
print('Multiplication 2*D34@M2. Size: {}'.format(M3.shape))
print(M3)

M4= M3*M3 # Element-wise multiplication of M3*M3
print('Element-wise M3*M3. Size: {}'.format(M4.shape))
print(M4)
