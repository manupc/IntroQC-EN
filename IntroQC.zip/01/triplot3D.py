"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import matplotlib.pyplot as plt
import numpy as np
from IPython.display import display

# Create 3D image
f = plt.figure(figsize=(7,7))
ax = plt.axes(projection ='3d') # 3D projection axes


# theta and phi values to draw the sphere
theta_range= np.linspace(start= 0, stop= 2*np.pi, num= 15)
phi_range= np.linspace(start= 0, stop= np.pi, num= 15)
thetas, phis= np.meshgrid(theta_range, phi_range)

# Calculate sphere point coordinates
x = (np.sin(phis) * np.cos(thetas))
y = (np.sin(phis) * np.sin(thetas))
z = np.cos(phis)

# plot sphere with lines
ax.plot_wireframe(x, y, z, color="black", linewidth=0.5, alpha=0.7)
plt.show()
display(f)

# Plot sphere with a surface
ax.plot_surface(x, y, z, alpha=0.2)
plt.show()
display(f)

