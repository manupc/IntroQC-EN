"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Two arrays x,y of size 6
x= np.linspace(0, 1, 6) # 1st array
y= np.linspace(1, 2, 6) # 2nd array
r= 2 # A real value

print('Array x: {}'.format(x))
print('Array y: {}'.format(y))
print('Real value r: {}'.format(r))

# Arithmetic operations on arrays
print('x+y: {}'.format( x+y ))
print('x-y: {}'.format( x-y ))
print('x*y: {}'.format( x*y ))
print('x/y: {}'.format( x/y ))

# Functions on arrays
print('sqrt(x): {}'.format( np.sqrt(x) ))
print('-x: {}'.format( -x ))
print('|-x|: {}'.format( np.abs(-x) ))
print('x^r: {}'.format(x**r))
print('sum( x ): {}'.format( np.sum(x) ))
print('prod( y ): {}'.format( np.prod(y) ))

# Arothmetic operations on arrays and real numbers
print('2r+x-3: {}'.format( 2*r+x+3 ))
print('2*x/4: {}'.format( 2*x/4 ))
