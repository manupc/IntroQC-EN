"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import matplotlib.pyplot as plt

# Probability distribution as a Dictionary
Pdict= {'rainy' : 0.5,
    'sunny'  : 0.3, 
    'cloudy'  : 0.2
    }

# Values of variable as a NumPy array
X= np.array([ key for key in Pdict])

# Probability distribution as an array
P= np.array([ Pdict[key] for key in Pdict ])

print('Random variable X with values: {}'.format(X))


N= 100000 # Number of samples to get from the variable
samples= np.random.choice(X, size=N, replace= True, p=P)

n= np.zeros( len(X) , dtype=int) # Array to store absolute frequency values
for i, x_i in enumerate(X):
    n[i]= np.sum( samples==x_i )
    print('{} samples of weather {}'.format(n[i], x_i))
print('Total: {} samples'.format( np.sum(n) ))

f= n/N # Calculate relative freq. to approximate p(V[i])
for i, x_i in enumerate(X):
    print('Approximation of p({})= {}'.format(X[i], f[i]))

# Generate histogram
f= plt.figure()
plt.hist(samples)
plt.show()