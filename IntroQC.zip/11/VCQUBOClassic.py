"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Adjacency matrix of the graph
M = np.array([[0, 1, 0, 1, 1, 0],
              [1, 0, 1, 0, 1, 1],
              [0, 1, 0, 1, 0, 1],
              [1, 0, 1, 0, 0, 0],
              [1, 1, 0, 0, 0, 1],
              [0, 1, 1, 0, 1, 0]])

print('Initial representation of the problem with the adjacency matrix:')
print(M)

# Creation of variables for the QUBO model
n = len(M) # No. of variables
x = Array.create('x', shape=(n,), vartype='BINARY')


### QUBO Model
# Calculate cost function f(x)=x1+x2+x3+x4+x5+x6
Q = 0
for i in range(n):
    Q += x[i]

# Include penalties
P = 20 # Common penalty scalar for all constraints
for i in range(n):
    for j in range(i + 1, n):
        if M[i, j] != 0: # Penalize exclusion of edge (vi, vj)
            Q += P * (1 - x[i] - x[j] + x[i] * x[j])


# Create theoretical QUBO model
model = Q.compile()
qubo, offset = model.to_qubo()
print('\nQUBO model with penalty P={}:'.format(P))
for key in qubo:
    print(key, qubo[key])

# Create binary quadratic model (BQM)
bqm = model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots = 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Get the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars = best_sample.sample
best_sample_cost = best_sample.energy

# Convert solution to NumPy
solution = np.zeros(len(M), dtype=int)
for var in best_sample_vars:
    for i, x_i in enumerate(x):
        if var in str(x_i):
            solution[i] = best_sample_vars[var]

# Show solution
# and its cost
print('\nBest Solution: x={} with cost f(x)={}'.format(solution, best_sample_cost))

