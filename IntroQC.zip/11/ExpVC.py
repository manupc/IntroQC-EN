"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getVertexCoverProblem, ProblemCircuit, IsingToPauli, IsingHamiltonian
from qiskit import transpile
from qiskit_aer import AerSimulator
from IPython.display import display
from scipy.linalg import expm

# Adjacency matrix of the graph
M = np.array([[0, 1, 1, 1],
              [1, 0, 0, 0],
              [1, 0, 0, 0],
              [1, 0, 0, 0]])

print('Initial problem representation with the adjacency matrix:')
print(M)

# Creation of the Ising model
P = 1  # Penalty factor
z, model = getVertexCoverProblem(M, P)
ising = model.to_ising()

# Transform the Ising model to a sequence of Pauli operators
pauli = IsingToPauli(z, ising)

# Creation of the Hamiltonian exponential circuit with a fixed t value
t = 1
qc = ProblemCircuit(pauli, t, reverse_ops=True)
qc.save_unitary()

# We display the circuit graphically
f = qc.draw('mpl')
display(f)

# Simulation of the circuit to obtain the unitary matrix
sim = AerSimulator()
n_shots = 1
U = sim.run(transpile(qc, sim), shots=n_shots).result().get_unitary()
U = U.data

# We calculate the exponential of H manually
H = IsingHamiltonian(pauli)
expH = expm(-1.j * t * H)

# We get the scaling factor between matrices
# from the top-left coordinate of both
factor = np.diag(U)[0] / np.diag(expH)[0]

# We multiply the manually calculated exponential by the factor,
# To compare both matrices
expH *= factor

# We compare both matrices
if np.all(np.isclose(expH, U.data)):
    print('The circuit matrix is equal to exp(H) with factor= {}'.format(factor))
else:
    print('The circuit matrix is not equal to exp(H)')



