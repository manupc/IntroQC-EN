"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getMaxCutProblem, getVertexCoverProblem, getGraphColoringProblem
from OptimizationTools import energy_classic, energy_hamiltonian, IsingToPauli, IsingHamiltonian

problems = {
    'MaxCut': lambda M: getMaxCutProblem(M),
    'VertexCover': lambda M: getVertexCoverProblem(M, P=1),
    'GraphColoring': lambda M: getGraphColoringProblem(M, K=2, P1=1, P2=1)
}


# Adjacency matrix of the graph
M = np.array([[0, 1, 1],
              [1, 0, 0],
              [1, 0, 0]])

print('Initial problem representation with the adjacency matrix:')
print(M)


for problem in problems:
    
    # Create theoretical model
    print('\nSolving the {} problem'.format(problem))
    print('-' * 50, '\n')
    z, model = problems[problem](M)
    
    # Convert to Ising
    ising = model.to_ising()
    
    # Build sequence of Pauli operators
    pauli = IsingToPauli(z, ising)
    
    # Generate Hamiltonian matrix H
    H = IsingHamiltonian(pauli)
    
    # Evaluate all possible solutions
    n = np.prod(z.shape)  # Total number of combinations
    for x in range(2**n):
        
        # convert x to binary
        x_bin = np.array([int(xi) for xi in bin(x)[2:].rjust(n, '0')])
        
        cost_classic = energy_classic(x_bin, pauli)
        cost_hamiltonian = energy_hamiltonian(x, H)
        print('\tThe solution x={} has a cost of {} with classical evaluation and a cost of {} with Hamiltonian evaluation'.format(x_bin, cost_classic, cost_hamiltonian))