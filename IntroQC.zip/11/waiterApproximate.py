"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np


# Simulated Annealing Algorithm. It requires:
#   x_init: A valid initial solution to the problem
#   cost_f: The cost function, cost_f(x)
#   neighbor_f: The neighbor generation function, neighbor_f(x)
#   T_init: The initial temperature
#   T_factor: The multiplicative cooling factor for the temperature
#   max_iter: The maximum number of algorithm iterations without improvement of the best solution
# Returns a solution x to the problem (np.ndarray)
def SA_optimizer(x_init : np.ndarray, cost_f : callable, 
                 neighbor_f : callable, T_init : float, T_factor : float, 
                 max_iter : int):
    
    # Parameter initialization
    T = T_init  # Temperature
    x, fx = x_init.copy(), cost_f(x_init)  # Current solution and its cost
    bx, fbx = x.copy(), fx  # Best solution found so far and its cost
    
    iter_count = 0  # Counter for the number of algorithm iterations without improving bx
    while iter_count < max_iter:  # Main loop
    
        update = False  # To check if we have updated the best solution
    
        # Generate a neighboring solution
        xp = neighbor_f(x) 
        fxp = cost_f(xp)
        
        # Decision on accepting the generated solution
        f_diff = fxp - fx
        
        # If the new solution is better, we always accept it.
        # If it is worse, we accept it with a decreasing probability (Metropolis Criterion).
        if f_diff < 0 or np.random.uniform() < np.exp(-f_diff / T):
            x, fx = xp, fxp
            
            # Update the best solution found so far if necessary
            if fx < fbx:
                bx, fbx = x.copy(), fx
                update = True

        # Reset the iteration counter because we have improved,
        # or update it if we have not.
        iter_count = 0 if update else iter_count + 1
            
        # Cool down the system
        T *= T_factor

    return bx



# Procedure to implement the cost function. It takes the
# solution x and the problem description t (times for each customer) as input.
# As output, it returns a scalar value with the cost.
def f(x : np.ndarray, t : np.ndarray):
    
    n = len(x)  # Number of customers
    fx = 0      # Value of the cost function
    for i in range(1, n + 1):
        fx += np.sum(t[x[:i]])
    return fx


# Function to return a neighboring solution to solution x.
# It generates a permutation of solution x by swapping two of its elements.
def neighbour_generator(x : np.array):
    pos = np.random.randint(low=0, high=len(x), size=2)
    x_prime = x.copy()
    x_prime[pos[0]] = x[pos[1]]
    x_prime[pos[1]] = x[pos[0]]
    return x_prime


# Case for n=3 customers. Time for each customer.
t = np.array([7, 1, 4])


# Cost function as a lambda to fit the function f to the solver's format.
cost_f = lambda x: f(x, t)

n = len(t) # Number of variables

# Initial solution: [0, 1, 2, ..., n-1]
x_init = np.array(list(range(n)), dtype=int)

# Algorithm parameters
T_init = 200     # Initial temperature
T_factor = 0.9   # Cooling factor
max_iter = 10

# Call the optimization algorithm
x = SA_optimizer(x_init, cost_f, neighbour_generator, T_init, T_factor, max_iter)

fx = f(x, t) # Calculate cost function


# Display solution 
print('Numbering for {} customers: {} with times t={}'.format(len(x), list(range(len(x))), t))
print('Serve customers in order x={}, with f(x)={}'.format(x, fx))