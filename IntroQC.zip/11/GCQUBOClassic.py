"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Adjacency matrix of the graph
M = np.array([[0, 1, 0, 0, 0, 0],
              [1, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 0, 1],
              [0, 1, 1, 0, 0, 1],
              [0, 0, 0, 1, 1, 0]])

print('Initial representation of the problem with the adjacency matrix:')
print(M)

# Creation of variables for the QUBO model
n = len(M) # No. of vertices
K = 2 # No. of colors
x = Array.create('x', shape=(n, K), vartype='BINARY')

### QUBO Model
# There is no cost function f(x)
Q = 0

# Include penalties
P = 1 # Common penalty scalar for all constraints

# Constraint 1: A node can only have one color
for i in range(n):
    Q_aux = -1
    for k in range(K):
        Q_aux += x[i][k]
    Q += P * Q_aux**2

# Constraint 2: Two adjacent nodes with different colors
for i in range(n):
    for j in range(i + 1, n):
        if M[i, j] != 0:
            Q_aux = 0
            for k in range(K):
                Q_aux += x[i][k] * x[j][k]
            Q += P * Q_aux

# Create theoretical QUBO model
model = Q.compile()
qubo, offset = model.to_qubo()
print('\nQUBO model with penalty P={}:'.format(P))
for key in qubo:
    print(key, qubo[key])

# Create binary quadratic model (BQM)
bqm = model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots = 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)

# Get the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars = best_sample.sample
best_sample_cost = best_sample.energy


# Convert solution to NumPy
solution_bin= np.zeros(x.shape, dtype=int)
for var in best_sample_vars:
    for i in range(x.shape[0]):
        for j in range(x.shape[1]):
            if var in str(x[i,j]):
                solution_bin[i,j]= best_sample_vars[var]

solution=np.zeros(x.shape[0], dtype=int) # From binary to integer
for i in range(len(solution)):
    solution[i]= np.where(solution_bin[i]==1)[0][0]

print('\nSolution: x={} with penalty f(x)={}'.format(solution, best_sample_cost))

