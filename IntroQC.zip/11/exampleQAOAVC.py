"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""




import numpy as np
from OptimizationTools import getVertexCoverProblem as ProblemFormulation
from OptimizationTools import energy_classic, QAOAcirc, run_circuit_expectation, getBestSolution, IsingToPauli
from qiskit import transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
from scipy.optimize import minimize
from IPython.display import display


# Adjacency matrix of the graph
M= np.array([[0 , 1 , 1, 1],
              [1 , 0 , 0, 0],
              [1 , 0 , 0, 0],
              [1 , 0 , 0, 0]])

print('Initial problem representation with the adjacency matrix:')
print(M)


# Creation of the Ising model
z, model= ProblemFormulation(M, P=1)
ising= model.to_ising()

# Conversion from the Ising model to a sequence of Pauli operators
pauli= IsingToPauli(z, ising)

# Creation of the QAOA circuit with L layers and shots measurements
L= 1
shots= 1024
gamma, beta, qaoa_circ= QAOAcirc(L, pauli)

# Preparation of the simulator and the function to be optimized
sim= AerSimulator()
to_be_minimized= lambda params : run_circuit_expectation(params, qaoa_circ, sim, shots, pauli)


# Initial parameters for beta and gamma
params_init= np.random.rand(2*L) 

# Optimization of gamma and beta with COBYLA
params = minimize(to_be_minimized,
                  params_init,
                  method='COBYLA').x

print('\nBest parameters: {}'.format(params))

# Execution of the QAOA circuit with the best parameters
res_circ= qaoa_circ.assign_parameters(params)
counts = sim.run(transpile(res_circ, sim), shots= shots).result().get_counts()

# Display histogram of the measurements
f= plot_histogram(counts)
display(f)

# Get the best solution
solution_bin= getBestSolution(counts)
x= np.array([int(xi) for xi in solution_bin])
cost= energy_classic(x, pauli)

print('Best solution found (binary): {} with energy cost={}'.format(solution_bin, cost))