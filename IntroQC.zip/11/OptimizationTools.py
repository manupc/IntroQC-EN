"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
import re
from pyqubo import Array, DecodedSample
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit.quantum_info import SparsePauliOp
from itertools import product


###########################################################
# BRUTE FORCE METHOD
###########################################################


# Exact brute-force algorithm to find the optimal solution
# to an optimization problem (minimization).
# As input, it needs the number of variables in the problem (n), a list D of
# n lists with the possible values for each variable, a boolean function
# constraints_f(x) to verify that a solution x to the problem meets
# its constraints (returns True) or not (returns False),
# and a cost function cost_f(x) that returns the cost of a solution.
# As output, it returns an optimal solution x to the problem (np.ndarray).
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx= None # Initialization of the optimal solution
    fbx= np.inf # Cost of the optimal solution
    
    all_solutions_generator= product(*D) # Generator for all possible solutions
    for x in all_solutions_generator:
        
        x= np.array(x)
        
        # Check if x meets the constraints
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx= cost_f(x) # Calculate the cost of the solution
        if fx < fbx: # Update the best solution found
            bx, fbx= x, fx
    return np.array(bx)



###########################################################
# UTILITIES
###########################################################



# From a solver solution given as input
# and a set of variables z on which the solution is built,
# the function returns a NumPy array indexed like z, whose values
# correspond to those found by the solver (value), as well as the energy
# value of the solution.
def sampledSolutionToNumPy(solution : DecodedSample, z: Array):
    
    # Get the value of e(z)
    sol_cost= solution.energy

    # Get the indices of the solutions in z
    indices= [list(range(i)) for i in z.shape]
    
    z_idx= list(product(*indices))
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    # Generate the final NumPy solution
    npsol= np.zeros(z.shape, dtype=int)
    
    # Assign each component of npsol to its solution value
    for idx in z_idx:
        val= solution.array('z', tuple(idx))
        npsol[*idx]= val
    return npsol, sol_cost


# For a PyQUBO Array z, the function generates a dictionary
# with variable names (key) and a unique index (integer value).
def getVarIndices(z : Array):
    
    # Get all the indices of the solutions in z
    indices= [list(range(i)) for i in z.shape]
    z_idx= list(product(*indices)) 
    z_idx= np.array(z_idx, dtype=int).squeeze()
    if len(z_idx.shape) == 1:
        z_idx= z_idx.reshape(-1, 1)
    
    var_ind= {} # Generate a dictionary (variable name : integer index)
    for i, ind in enumerate(z_idx):
        
        # Remove the prefix Spin(' and the suffix ')
        name= str(z[tuple(ind.tolist())])[6:-2]
        var_ind[name]= i # Assign variable name to index
    return var_ind

    


###########################################################
# PROBLEM FORMULATION
###########################################################


# Given a graph's adjacency matrix as input, the function
# returns the variables and the compiled model of a Max-Cut problem formulation.
def getMaxCutProblem(M : np.ndarray):

    # Creation of variables for the Ising model
    n= len(M) # No. of variables
    z = Array.create('z', shape=(n,), vartype='SPIN')
    
    Ising= 0 # Ising model
    # Calculate the problem formulation
    for i in range(M.shape[0]):
        for j in range(i+1, M.shape[1]):
            if M[i,j] != 0:
                Ising+= z[i]*z[j] # Ising model, edge (vi, vj)
    
    # Create the theoretical Ising model
    model= Ising.compile()
    return z, model


# Given a graph's adjacency matrix as input, the function
# returns the variables and the compiled model of a Vertex Cover problem formulation.
# The optional parameter P is a scalar with the penalty to include.
def getVertexCoverProblem(M : np.ndarray, P : float = 20):

    # Creation of variables for the Ising model
    n= len(M) # No. of variables
    z = Array.create('z', shape=(n,), vartype='SPIN')

    Ising= 0 # Ising model

    # Cost function
    for i in range(n):
        Ising+= z[i]
        
    # Include penalties
    for i in range(n):
        for j in range(i+1, n):
            if M[i,j] != 0: # Penalize exclusion of edge (vi, vj)
                Ising+= P*(1-z[i])*(1-z[j])

    # Create the theoretical Ising model
    model= Ising.compile()
    return z, model


# Given a graph's adjacency matrix as input, the function
# returns the variables and the compiled model of a
# graph coloring decision problem formulation.
# The parameter K includes the maximum number of colors to use.
# P1 penalizes multiple colors for one node, and P2 penalizes adjacent nodes with the same color.
def getGraphColoringProblem(M : np.ndarray, K : int = 2, P1 : float = 2, P2 : float = 1):

    # Creation of variables for the Ising model
    n= len(M) # No. of vertices
    z = Array.create('z', shape=(n,K), vartype='SPIN')
    
    Ising= 0 # Ising model
        
    # Constraint 1: A node can only have one color
    for i in range(n):
        Ising_aux=0
        for k in range(K):
            Ising_aux+= z[i][k]
        Ising_aux= (K-2+Ising_aux)**2
        Ising+= P1 * Ising_aux
    
    # Constraint 2: Two adjacent nodes must have different colors
    for i in range(n):
        for j in range(i+1, n):
            if M[i,j]!= 0:
                Ising_aux= 0
                for k in range(K):
                    Ising_aux+= z[i][k]*z[j][k]
                Ising+= P2 * Ising_aux

    # Create the theoretical Ising model
    model= Ising.compile()
    return z, model



###########################################################
# PROBLEM EVALUATION
###########################################################

# Transforms an Ising model into a sequence of Pauli operators.
def IsingToPauli(z, ising, show=False, to_little_endian= False):
    
    var_idx= getVarIndices(z) # Assign each variable in z to an integer index
    n= np.prod(z.shape) # Number of required qubits
    
    seq= [] # Sequence of Pauli operators
    for ising_elm in ising:
        if not isinstance(ising_elm, float): # Skip the constant term
            for ZiZj in ising_elm: # Iterate over Zi or ZiZj variables
                
                # Create string representation of ID operations on each qubit
                pauli_tensor= ['I']*n 
                
                # Get the Zi or ZiZj variables involved in the ZiZj term
                var= (ZiZj,) if not isinstance(ZiZj, tuple) else ZiZj
                for zi in var: # Iterate over them
                    idx= var_idx[zi] # Get the index assigned to the variable
                    pauli_tensor[idx]= 'Z' # Apply Z operation on the variable's qubit
                coef= ising_elm[ZiZj] # Get the multiplying coefficient Jij * ZiZj
                
                # Convert pauli_tensor list to a string
                str_pauli= ''.join(var for var in pauli_tensor)
                if to_little_endian:
                    str_pauli= str_pauli[::-1]
                
                # Insert the pair (str_pauli, coef) into the sequence of Pauli operators
                seq.append( (str_pauli, coef) )
    if show:
        print('List of Pauli operators for H_P: {}'.format(seq))
    return SparsePauliOp.from_list(seq) # return seq as a sequence of Pauli operators


# Calculates the Ising Hamiltonian matrix 
# for the given sequence of Pauli operators as input.
def IsingHamiltonian(pauli : SparsePauliOp):
    
    n= pauli.num_qubits # Number of variables in the problem
    I, Z= np.eye(2), np.array([[1, 0], [0, -1]]) # ID and Z matrices
    H= np.zeros((2**n, 2**n)) # Hamiltonian matrix
    
    # Create H_hat
    for oper in pauli:
        
        # Get the coefficient associated with the Pauli operator (real number)
        coef= float(oper.coeffs.squeeze().real)
        
        # Get the string representing the gates that make up the operator
        gates= str( oper.paulis[0] )
        
        # Calculate the matrix associated with the gates
        prod= 1
        for matrix in gates:
            prod= np.kron(prod, Z if matrix=='Z' else I)
        H+= coef*prod # Incorporate the matrix into the Hamiltonian
    return H


# For a binary solution x=(x0, x1, ...) where xi has values 0/1, and given
# a sequence of Pauli operators H_P, the function returns the energy of the solution.
def energy_classic(x: np.ndarray, H_P : SparsePauliOp):
    
    z_spin= (2*x-1) # Move x to the set {-1, 1}
    Hz= 0 # Evaluate H(z), initialized to 0
    for pauli_op in H_P: # Iterate over all Pauli operators
    
        # Get the coefficient associated with the Pauli operator (real number)
        coef= float(pauli_op.coeffs.squeeze().real)
        
        # Get the string representing the gates that make up the operator
        gates= str( pauli_op.paulis[0] )
        
        # Get a list of positions where the Z gate is located
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Find the positions of the Z operator
            Zlist.append(z_pos.start())
        
        # Update the energy function
        Hz+= coef*np.prod(z_spin[ Zlist ])
    return Hz


# Pseudo-quantum calculation of the energy function
# of a solution |x>=|x1x2...> represented in ket format
# with respect to the Ising Hamiltonian H. Returns <x|H|x>.
def energy_hamiltonian( x: int, H : np.array):

    quantum_x= np.zeros(len(H)) # Convert x to |x>
    quantum_x[len(quantum_x)-1-x]= 1

    ket = quantum_x.reshape(-1,1) # Ket format of the solution
    bra= np.conjugate( np.transpose( ket ) ) # Bra format of the solution
    gx= bra @ H @ ket 
    return gx.squeeze()




###########################################################
# QAOA
###########################################################


# Construction of the circuit for the exponential of the Ising model
# with parameter t.
def ProblemCircuit(pauli : SparsePauliOp, t : float, reverse_ops : bool= False):
    
    # Generate the circuit
    n_qubits= pauli.num_qubits
    qc_problem= QuantumCircuit(n_qubits)
    
    # Iterate over each Pauli operator
    for oper in pauli:
        
        # Get the coefficient
        coef= float(oper.coeffs.squeeze().real) 
        
        # Get the Pauli matrices as a string
        gates= str(oper.paulis[0])[::-1] if reverse_ops else str(oper.paulis[0])
        
        # Get the positions of the qubits where the Z gates are applied.
        # Get a list of positions where the Z gate is located.
        Zlist= []
        for z_pos in re.finditer('Z', gates): # Find the positions of the Z operator
            Zlist.append(z_pos.start())
            
        if len(Zlist)==1: # Single Rz operation on one qubit
            qc_problem.rz(2*coef*t, Zlist[0])
        else: # Rzz operation on two qubits
            qc_problem.rzz(2*coef*t, Zlist[0], Zlist[1])
        
    return qc_problem


# Creation of the QAOA Mixer circuit with parameter beta.
def MixerCircuit(n_qubits, beta):
    qc_mixer= QuantumCircuit(n_qubits) # Create the circuit
    qc_mixer.rx(2*beta, range(n_qubits)) # Inclusion of parameterized Rx gates
    return qc_mixer


# Construction of the QAOA circuit for the Ising problem given by the
# sequence of Pauli operators with L layers.
def QAOAcirc(L : int, pauli : SparsePauliOp):
    
    # Generation of gamma/beta parameters
    n_qubits= pauli.num_qubits
    gamma= ParameterVector(length= L, name='gamma')
    beta= ParameterVector(length= L, name= 'beta')
    
    # Circuit creation: superposition
    qc= QuantumCircuit(n_qubits)
    qc.h(range(n_qubits))
    
    # L layers of Hamiltonian + mixer
    for l in range(L):
        qc= qc.compose(ProblemCircuit(pauli, gamma[l]))
        qc= qc.compose(MixerCircuit(n_qubits, beta[l]))
    qc.measure_all()
    return gamma, beta, qc


# Calculates the expectation value of <x|H_P|x> from
# the measurements given in counts by the circuit execution.
def ExpVal_from_counts(counts : dict, H_P: SparsePauliOp, reverse_ket= False):
    N= 0
    expval= 0
    for ket in counts:
        num_meas= counts[ket]
        N+= num_meas
        ket_rev= ket[::-1] if reverse_ket else ket
        ket_arr= np.array([int(xi) for xi in ket_rev])
        fx= energy_classic(ket_arr, H_P)
        expval+= fx*num_meas
    return expval/N


# Prepares the execution of an optimization circuit
# qaoa_circ with params values for gamma and beta,
# using the simulator sim with shots executions of the circuit.
# Returns the expectation value of the observable implemented in qaoa_circ.
def run_circuit_expectation(params, qaoa_circ, sim, shots, H_P, reverse_ket= False):
    qc= qaoa_circ.assign_parameters(params)
    counts= sim.run(transpile(qc, sim), shots= shots).result().get_counts()
    return ExpVal_from_counts(counts, H_P, reverse_ket)


# Gets the best (most probable) solution to a problem
# given the measurements performed in counts.
def getBestSolution(counts, to_big_endian= True):
    maxVal= 0
    bestket= None
    for ket in counts: # Find the ket with the highest measurement probability
        if counts[ket] > maxVal:
            maxVal= counts[ket]
            bestket= ket
    return bestket[::-1] if to_big_endian else bestket