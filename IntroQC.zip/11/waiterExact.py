"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from itertools import product


# Exact brute-force algorithm to find the optimal solution
# for an optimization (minimization) problem.
# As input, it requires the number of problem variables (n), a list D of
# n lists with the possible values for each variable, a boolean
# function constraints_f(x) to verify if a solution x meets the
# problem's constraints (returns True) or not (returns False),
# and a cost function cost_f(x) that returns the solution's cost.
# As output, it returns an optimal solution x for the problem (np.ndarray).
def exact_optimizer(n : int, D : list[list[int]], constraints_f : callable, cost_f : callable):
    
    bx = None      # Initialization of the optimal solution
    fbx = np.inf   # Cost of the optimal solution
    
    all_solutions_generator = product(*D) # Generator for all possible solutions
    for x in all_solutions_generator:
        
        x = np.array(x)
        
        # Check if x meets the constraints
        if constraints_f is not None and not constraints_f(x):
            continue
        
        fx = cost_f(x) # Calculate the solution's cost
        if fx < fbx:   # Update the best solution found
            bx, fbx = x, fx
    return np.array(bx)


# Procedure to implement the cost function. It takes the
# solution x and the problem description t (times for each customer) as input.
# As output, it returns a scalar value with the cost.
def f(x : np.ndarray, t : np.ndarray):
    
    n = len(x)  # Number of customers
    fx = 0      # Value of the cost function
    for i in range(1, n + 1):
        fx += np.sum(t[x[:i]])
    return fx


# Function to check if a solution x meets the constraints of the waiter's problem.
# Returns True if it does, and False otherwise.
def check_constraints(x : np.array):
    return len(np.unique(x)) == len(x) # Checks that there are no repeated elements in x


# Case for n=3 customers. Time for each customer.
t = np.array([7, 1, 4])


# Cost function as a lambda to fit the function f to the solver's format.
cost_f = lambda x: f(x, t)

n = len(t)              # Number of variables
D = [list(range(n))]*n  # Domain for each variable

# Call the optimization algorithm
x = exact_optimizer(n, D, check_constraints, cost_f)

fx = f(x, t) # Calculate cost function


# Display solution 
print('Numbering for {} customers: {} with times t={}'.format(len(x), list(range(len(x))), t))
print('Serve customers in order x={}, with f(x)={}'.format(x, fx))