"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np

# Function to solve the waiter's problem. It takes the service
# time for each customer as input. As output, it returns a list L
# where L[i] contains the customer that should be served in the i-th position.
def adhoc_optimizer(t : np.ndarray):
    
    x = np.argsort(t)
    return x


# Procedure to implement the cost function. It takes the
# solution x and the problem description t (times for each customer) as input.
# As output, it returns a scalar value with the cost function.
def f(x : np.ndarray, t : np.ndarray):
    
    n = len(x)  # Number of customers
    fx = 0      # Value of the cost function
    for i in range(1, n + 1):
        fx += np.sum(t[x[:i]])
    return fx


# Case for n=3 customers. Time for each customer.
t = np.array([7, 1, 4])

# Call the optimization algorithm
x = adhoc_optimizer(t)
fx = f(x, t) # Calculate the cost function


# Display solution 
print('Numbering for {} customers: {} with times t={}'.format(len(x), list(range(len(x))), t))
print('Serve customers in order x={}, with f(x)={}'.format(x, fx))