"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getMaxCutProblem, sampledSolutionToNumPy
from neal import SimulatedAnnealingSampler


# Adjacency matrix of the graph
M= np.array([[0,1,0,0,0,1],
             [1,0,1,0,1,0],
             [0,1,0,1,0,1],
             [0,0,1,0,1,0],
             [0,1,0,1,0,1],
             [1,0,1,0,1,0]])

print('Initial problem representation with the adjacency matrix:')
print(M)

# Create the theoretical model
z, model= getMaxCutProblem(M)
n= np.prod(z.shape) # Number of variables in the model

# Create the theoretical Ising model
ising_description= model.to_ising()

print('\nIsing Model:')
for coefs in ising_description:
    if not isinstance(coefs, dict):
        print(coefs)
    else:
        for key in coefs:
            print(key, coefs[key])

# Create the Binary Quadratic Model (BQM)
bqm= model.to_bqm()

# Apply simulated annealing to solve the Ising problem
# a total of n_shots times
n_shots= 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Get the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)

# Decode the solution to NumPy
solution, sol_cost= sampledSolutionToNumPy(best_sample, z)
print('\nBest Solution: z={} with energy e(z)={}'.format(solution, sol_cost))