"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import exact_optimizer


# Definition of the problem's adjacency matrix
M = np.array([[0, 1, 0, 0, 0, 0],
              [1, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 1, 0],
              [0, 0, 0, 0, 0, 1],
              [0, 1, 1, 0, 0, 1],
              [0, 0, 0, 1, 1, 0]
             ], dtype=int)

print("Problem's adjacency matrix:")
print(M)


# Procedure to implement the cost function. Returns a constant value
def f(x: np.ndarray):
    return 0


# Function to check if an input solution x meets the constraints
# imposed by the problem, given by the adjacency matrix M.
# Returns True if x meets the constraints, and False otherwise.
def is_valid(x: np.ndarray, M: np.ndarray):

    n = len(x)  # Number of variables

    # Iterate through each edge e_ij of the graph
    for i in range(n):
        for j in range(i + 1, n):
            if M[i][j] > 0:
                # Check if two adjacent nodes have the same color
                if x[i] == x[j]:
                    return False  # The solution is not valid
    return True  # No two adjacent nodes have the same color

# Adapt the is_valid function to the format required by the optimizer
check_constraints = lambda x: is_valid(x, M)

K = 2  # Number of colors to use
n = len(M)  # Number of problem variables
D = [list(range(K))] * n  # Domain of each variable

# Call the optimization algorithm
x = exact_optimizer(n, D, check_constraints, f)

fx = f(x)  # Calculate the cost function

# Display solution
print('Solution x={}, with f(x)={}'.format(x, fx))