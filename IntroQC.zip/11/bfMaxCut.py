"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import exact_optimizer


# Definition of the problem's adjacency matrix
M = np.array([[0, 1, 0, 0, 0, 1],
              [1, 0, 1, 0, 1, 0],
              [0, 1, 0, 1, 0, 1],
              [0, 0, 1, 0, 1, 0],
              [0, 1, 0, 1, 0, 1],
              [1, 0, 1, 0, 1, 0]
             ], dtype=int)

print('Problem Adjacency Matrix:')
print(M)


# Procedure to implement the cost function. It takes as input
# the solution x and the adjacency matrix M of the problem.
# As output, it returns a scalar value with the cost.
def f(x: np.ndarray, M: np.ndarray):
    
    n = len(x)  # Size of the solution
    fx = 0  # Value of the cost function
    for i in range(n):  # Iterate over indices xi
        for j in range(i + 1, n):  # Iterate over indices xj
            e_ij = M[i][j]  # 1 if edge e_ij exists, 0 otherwise
            diff = 1 if x[i] != x[j] else 0  # v_i and v_j are in different sets
            fx += e_ij * diff
    return -fx  # Sign change for minimization problems


# Cost function as a lambda to adapt function f to the solver's format
cost_f = lambda x: f(x, M)

n = len(M)  # Number of variables
D = [[0, 1]] * n  # Domain of each variable

# Constraint checking
check_constraints = None  # There are no constraints in this problem

# Call to the optimization algorithm
x = exact_optimizer(n, D, check_constraints, cost_f)

fx = f(x, M)  # Calculate cost function

# Display solution
print('Solution x={}, with f(x)={}'.format(x, fx))