"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from OptimizationTools import getVertexCoverProblem as ProblemFormulation
from OptimizationTools import IsingToPauli, getBestSolution, energy_classic, run_circuit_expectation
from qiskit import transpile
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
from scipy.optimize import minimize
from IPython.display import display
from qiskit.circuit.library import QAOAAnsatz


# Adjacency matrix of the graph
M= np.array([[0 , 1 , 1, 1],
              [1 , 0 , 0, 0],
              [1 , 0 , 0, 0],
              [1 , 0 , 0, 0]])

print('Initial problem representation with the adjacency matrix:')
print(M)



# Creation of the Ising model
z, model= ProblemFormulation(M, P=1)
ising= model.to_ising()

# Transformation from Ising model to a sequence of Pauli operators
H_P= IsingToPauli(z, ising, to_little_endian= True)

# Creation of the QAOA circuit
L= 1
params_init= np.random.rand(2) # Initial parameters for beta and gamma

qaoa_circ= QAOAAnsatz(cost_operator=H_P, reps= L)
qaoa_circ.measure_all()

f= qaoa_circ.decompose().decompose().draw('mpl')
display(f)


# Preparation of the simulator and the function to be optimized
sim= AerSimulator()
shots= 1024
to_be_minimized= lambda params : run_circuit_expectation(params, qaoa_circ, sim, shots, H_P)

# Optimization of gamma and beta 
res = minimize(to_be_minimized,
               params_init,
               method='COBYLA').x

# Get results from the best gamma and beta values
print('\nBest parameters: {}'.format(res))


# Execution of the QAOA circuit with the best parameters
res_circ= qaoa_circ.assign_parameters(res)
counts = sim.run(transpile(res_circ, sim), shots= shots).result().get_counts()

# Display histogram of the measurements
f= plot_histogram(counts)
display(f)

# Get the best solution
bestSol= getBestSolution(counts)
x= np.array([int(xi) for xi in bestSol])
cost= energy_classic(x, H_P)
print('Best solution found: {} with energy={}'.format(bestSol, cost))
