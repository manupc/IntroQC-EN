"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from pyqubo import Array
from neal import SimulatedAnnealingSampler


# Adjacency matrix of the graph
M = np.array([[0, 1, 0, 0, 0, 1],
              [1, 0, 1, 0, 1, 0],
              [0, 1, 0, 1, 0, 1],
              [0, 0, 1, 0, 1, 0],
              [0, 1, 0, 1, 0, 1],
              [1, 0, 1, 0, 1, 0]])

print('Initial representation of the problem with the adjacency matrix:')
print(M)

# Creation of variables for the QUBO model
x = Array.create('x', shape=(len(M),), vartype='BINARY')

# Coefficient matrix of the QUBO problem and formulation
C = np.zeros(M.shape, dtype=int)
Q = 0 # QUBO model

# Calculate C and Q
for i in range(M.shape[0]):
    for j in range(i + 1, M.shape[1]):
        if M[i, j] != 0:

            # Coefficient matrix
            C[i, i] -= 1
            C[j, j] -= 1
            C[i, j] = C[j, i] = 2

            # QUBO model
            current_edge = -x[i] - x[j] + 2 * x[i] * x[j]
            Q+= current_edge

print('\nCoefficient matrix C:')
print(C)

# Create theoretical QUBO model
model = Q.compile()
qubo, offset = model.to_qubo()
print('\nQUBO model:')
for key in qubo:
    print(key, qubo[key])

# Create binary quadratic model (BQM)
bqm = model.to_bqm()

# Apply simulated annealing to solve the QUBO problem
# a total of n_shots times
n_shots = 10
sa = SimulatedAnnealingSampler()
sampleset = sa.sample(bqm, num_reads=n_shots)
print('\nThe {} solutions obtained: '.format(n_shots))
print(sampleset)

# Get the best solution
decoded_samples = model.decode_sampleset(sampleset)
best_sample = min(decoded_samples, key=lambda x: x.energy)
best_sample_vars = best_sample.sample
best_sample_cost = best_sample.energy

solution = np.zeros(len(M), dtype=int)
for var in best_sample_vars:
    for i, x_i in enumerate(x):
        if var in str(x_i):
            solution[i] = best_sample_vars[var]

print('\nBest Solution: x={} with cost f(x)={}'.format(solution, best_sample_cost))

# Manual verification of the result
Q = np.triu(C) # Convert C to upper triangular matrix
print('\nVerification with upper triangular matrix of C:')
print('Q=\n', Q)

# Manually calculate f(x)=<x|^C|x>
x = solution.reshape(-1, 1)
fx = (x.T @ Q @ x).squeeze()
print('The value <x|Q|x> is {}'.format(fx))
