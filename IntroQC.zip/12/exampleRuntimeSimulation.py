"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_ibm_runtime.fake_provider import FakeSherbrooke as Simulator
from qiskit.visualization import plot_histogram
from IPython.display import display

# Circuit creation to generate the Bell state |Phi^+>
qr = QuantumRegister(2, 'qr')
cr = ClassicalRegister(2, 'cr')
qc = QuantumCircuit(qr, cr)
qc.h(qr[0])
qc.cx(qr[0], qr[1])
qc.measure(qr, cr)


# Access to the quantum computing service
backend = Simulator()
print('Assigned back-end: {} with {} qubits.'.format(backend.name, backend.num_qubits))


# We transform the circuit to the instruction set of the assigned quantum computer
qct = transpile(qc, backend)

# Display transpiled circuit
f = qct.draw('mpl')
display(f)

print('Job queued. Waiting for our turn...')
results = backend.run([qct], shots=1024).result()
counts = results.get_counts()  # Get the number of times each possible measurement occurred

print('\nResults: ')
for ket in counts:
    print('{}: {}'.format(ket, counts[ket]))
f = plot_histogram(counts)
display(f)