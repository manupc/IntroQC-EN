"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from time import sleep
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
from qiskit.visualization import plot_histogram
from IPython.display import display

# Circuit creation to generate the Bell state |Phi^+>
qr = QuantumRegister(2, 'qr')
cr = ClassicalRegister(2, 'cr')
qc = QuantumCircuit(qr, cr)
qc.h(qr[0])
qc.cx(qr[0], qr[1])
qc.measure(qr, cr)


# We obtain our token, which we have previously saved to a file.
# WARNING: The rest of the program will not work correctly if
# we have not opened the account in IBM Cloud and followed the instructions
# to store the API token in the APItoken.txt file in the folder
# of the source code associated with the book
with open('APItoken.txt', 'r') as f:
    APIkey = f.readline()[:-1] # We avoid the final newline character '\n'
    CRN = f.readline()[:-1]

# Request for access to the provider
service = QiskitRuntimeService(
    channel='ibm_quantum_platform',
    instance=CRN,
    token=APIkey
)

# Access to the quantum computing service
backend = service.least_busy(min_num_qubits=2, simulator=False, operational=True)
print('Assigned back-end: {} with {} qubits.'.format(backend.name, backend.num_qubits))

# Creation of the service for performing measurements
sampler = Sampler(backend)

# We transform the circuit to the instruction set of the assigned quantum computer
qct = transpile(qc, backend)

# Display transpiled circuit
f = qct.draw('mpl')
display(f)

print('Job queued. Waiting for our turn...')
job = sampler.run([qct], shots=1024)
print('Job ID: {}.'.format(job.job_id()))

while not job.in_final_state():
    sleep(10)
    print('Job status: {} ({} s.)'.format(job.status(), job.usage()))
    print('Job metrics:')

    metrics = job.metrics()
    for m in metrics:
        print('\t{} : {}'.format(m, metrics[m]))

print('\nJOB FINISHED.')

# Check for job completion
try:
    done = job.done()
except:
    done = False

# Check for errors
error = False
if not done:
    try:
        error = job.errored()
        errorMessage = job.error_message()
    except:
        error = False

# Display execution results
if error:
    print('The job could not be completed: {}'.format(errorMessage))

elif done:
    # Obtain results
    sampler_results = job.result()[0]
    data = sampler_results.join_data() # Join all bit results
    counts = data.get_counts() # Get the number of times each possible measurement occurred

    print('\nResults: ')
    for ket in counts:
        print('{}: {}'.format(ket, counts[ket]))
    f = plot_histogram(counts)
    display(f)
else:
    print('Error: No results were obtained')