"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit_ibm_runtime import QiskitRuntimeService


# We get our token that we previously saved to a file
# WARNING: The rest of the program will not work correctly if
# we have not opened the account in IBM Cloud and followed the instructions
# to store the API token in the APItoken.txt file in the folder
# of the source code associated with the book
with open('APItoken.txt', 'r') as f:
    APIkey = f.readline()[:-1]  # We avoid the final newline '\n'
    CRN = f.readline()[:-1]



# Request for access to the provider
service = QiskitRuntimeService(
    channel='ibm_quantum_platform',
    instance=CRN,
    token=APIkey
)

# Display information about the free access plan or subscription
print('\nInformation about the free access plan or subscription:')
usage = service.active_account()
for k in usage:
    if k == 'token' or k == 'instance':
        usage[k] = '(...)'
    print('\t{} : {}'.format(k, usage[k]))

# Instances that we have active at this moment
print('\nInstances started or running:')
instances = service.instances()
for instance in instances:
    print('Name: {}'.format(instance['name']))
    for data in instance:
        if data == 'crn':
            instance[data] = '(...)'
        print('\t{} : {}'.format(data, instance[data]))

# Access to the quantum computing service.
backend = service.least_busy(simulator=False, operational=True)
print('\nBack-end access allowed. Back-end data:')
print('\tName: {}'.format(backend.name))
print('\tNo. qubits: {}'.format(backend.num_qubits))
print('\tVersion: {}'.format(backend.backend_version))
print('\tProvider: {}'.format(backend.provider))
print('\tSupported operations: {}'.format(backend.operation_names))
print('\tDescription: {}'.format(backend.description))