"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator


# Load dataset and select features
dataset= np.load('iris.npy', allow_pickle=True).item()
X, Y = dataset['data'][:, -2:], dataset['target']

# Transform X to angles
mini, maxi = np.min(X, axis=0), np.max(X, axis=0)
X = np.pi * (X - mini) / (maxi - mini)


n_shots = 2048 # Number of shots to perform

# Build the classification model in Qiskit
# 1. State preparation circuit
x_par = ParameterVector('x', 2) # Input parameter encoding

# Encode flower attributes in magnitude and phase
qc_p = QuantumCircuit(1, 1)
qc_p.rx(x_par[0], 0)
qc_p.rz(x_par[1], 0)

# 2. Ansatz circuit
thetas = ParameterVector('theta', 3) # Ansatz parameters
qc_a = QuantumCircuit(1, 1)
qc_a.rx(thetas[0], 0)
qc_a.ry(thetas[1], 0)
qc_a.rz(thetas[2], 0)

# 3. Build the complete decision circuit
qc_model = qc_p.compose(qc_a)


# 4. Circuits for measurement on the three axes
# Measurement on the Z-axis: No basis change needed
qc_ejez = QuantumCircuit(1, 1)
qc_ejez.measure(qubit=0, cbit=0)

# Basis change to measure on the X-axis
qc_ejex = QuantumCircuit(1, 1)
qc_ejex.h(0)
qc_ejex.measure(qubit=0, cbit=0)

# Basis change to measure on the Y-axis
qc_ejey = QuantumCircuit(1, 1)
qc_ejey.sdg(0)
qc_ejey.h(0)
qc_ejey.measure(qubit=0, cbit=0)


# Create model circuits for measurement on the three axes
qc_modelZ = qc_model.compose(qc_ejez)
qc_modelX = qc_model.compose(qc_ejex)
qc_modelY = qc_model.compose(qc_ejey)


# Instantiate the Aer simulator
sim = AerSimulator(method='statevector')

# Function that executes the estimation model (Quantum Circuit)
# INPUTS:
#   X: Input values
#   param: Estimation model parameters
# OUTPUTS:
#   counts_pred, the estimated outputs by the model
def model(X, param):

    # Get the measurement circuit on the three axes
    # for each pattern (flower)
    qcs = [qc_modelZ.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X]
    qcs.extend( [qc_modelX.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X] )
    qcs.extend( [qc_modelY.assign_parameters( {x_par : x_i, thetas : param} ) for x_i in X] )


    # Optimize all circuits and execute simulation on them
    qcts = transpile(qcs, sim)
    result = sim.run(qcts, shots=n_shots).result()
    
    # Calculate how many times each ket of interest is measured
    countsZ, countsX, countsY = [], [], []
    for i, circuit in enumerate(qcs):
        counts = result.get_counts( circuit )
        value = 0 if '0' not in counts else counts['0']
        if i < len(X):
            countsZ.append(value)
        elif i < 2 * len(X):
            countsX.append(value)
        else:
            countsY.append(value)

    # Group how many times |0>, |+>, |i> are measured
    counts_pred = np.array([countsZ, countsX, countsY], dtype=int).T
    y_pred = np.argmax(counts_pred, axis=1)
    return y_pred


# Evaluate a circuit on a dataset and calculate the error committed
E_f = lambda param : 100 * np.mean( model(X, param) != Y )


# Optimize the circuit
thetas_init = [0.5, 0.2, 0.25] # Initial guess for thetas

from scipy.optimize import minimize
print('Searching for best parameters. Please wait...')
result = minimize(fun=E_f,
                  x0=thetas_init,
                  method='COBYLA')
thetas_best = result.x
print('Finished. Best parameters: {}'.format(thetas_best))

# The final test
# (Uncomment the following line to check the example from the book)
error_best = E_f(thetas_best)
print('\nBest error: {:.2f} %'.format(error_best))