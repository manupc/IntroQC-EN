"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
import numpy as np


## Example of RXGate usage
qcrx = QuantumCircuit(1)
qcrx.rx(theta=np.pi / 2, qubit=0)

# Save the unitary matrix of the circuit
qcrx.save_statevector()

# Aer simulator instantiation
simulator = AerSimulator(method='statevector')

# Rewrite circuit to meet device conditions
# where it will be executed
qct = transpile(qcrx, simulator)

# Aer simulator instantiation
result = simulator.run(qct, shots=1).result()
svrx = result.get_statevector(qct)


## Example of H and Sdg usage
qc_HSdg = QuantumCircuit(1)
qc_HSdg.h(qubit=0)
qc_HSdg.sdg(qubit=0)

# Save the unitary matrix of the circuit
qc_HSdg.save_statevector()

# Aer simulator instantiation
simulator = AerSimulator(method='statevector')

# Rewrite circuit to meet device conditions
# where it will be executed
qct = transpile(qc_HSdg, simulator)

# Aer simulator instantiation
result = simulator.run(qct, shots=1).result()
sv_HSdg = result.get_statevector(qct)


print('\nResult of applying Rx(pi/2)|0>:', svrx)
print('SdgH|0>:', sv_HSdg)



