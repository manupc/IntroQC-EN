"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

thetas = ParameterVector('theta', 3) # Creation of a parameter array

# State preparation circuit
qc = QuantumCircuit(1)
qc.ry(thetas[0], 0)
qc.p(thetas[1], 0)
qc.ry(thetas[2], 0)

qc.save_statevector()

# Final circuit
display(qc.draw('mpl'))

# Encoding parameters from X to W
thetas_values = [[np.pi, np.pi, 0],  # thetas
                 [np.pi / 2, np.pi, np.pi / 2]] # other thetas


expected_svs = [Statevector([0, -1]),
                Statevector.from_label('0')]


# Parameter assignment: As many circuits as options
sim = AerSimulator()
allCircuits = [transpile(qc.assign_parameters({thetas: values}), sim) for values in thetas_values]


# Simulation
results = sim.run(allCircuits, shots=1).result()


# Calculate how many times we were correct
for exp_sv, qc, params in zip(expected_svs, allCircuits, thetas_values):
    sv = results.get_statevector(qc)
    print('\nStatevector obtained for thetas={}:'.format(params))
    print(sv)
    print('Expected Statevector:')
    print(exp_sv)