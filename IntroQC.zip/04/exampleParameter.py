"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import Parameter
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator

phi = Parameter('phi') # Creation of the parameter phi

# Parameterized quantum circuit
qc = QuantumCircuit(1)
qc.ry(phi, 0)

qc.save_statevector()


# Possible values for the parameters
phi_values = [np.pi / 2, np.pi]
expected_states = ['+', '1']

# Instantiate simulator with default 'automatic' method
sim = AerSimulator()

for expected, phi_val in zip(expected_states, phi_values):

    # Assign parameters to the circuit
    qc_bounded = qc.assign_parameters({phi: phi_val})

    # Transpilation and simulation
    qct = transpile(qc_bounded, sim)
    sv = sim.run(qct, shots=1).result().get_statevector()

    print('\nResulting Statevector for phi={}:'.format(phi_val))
    print(sv)
    print('Expected Statevector:')
    print('|{}>: {}'.format(expected, Statevector.from_label(expected)))