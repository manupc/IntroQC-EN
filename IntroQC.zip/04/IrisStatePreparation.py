"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator



# Load dataset and select features
dataset= np.load('iris.npy', allow_pickle=True).item()
X, Y_all = dataset['data'][:, -2:], dataset['target']

# Transform X to angles
mini, maxi = np.min(X, axis=0), np.max(X, axis=0)
X = np.pi * (X - mini) / (maxi - mini)

# Build the classification model in Qiskit
# 1. State preparation circuit
x_par = ParameterVector('x', 2) # Input parameter encoding

# Encode flower attributes in magnitude and phase
qc_p = QuantumCircuit(1, 1)
qc_p.rx(x_par[0], 0)
qc_p.rz(x_par[1], 0)
qc_p.save_state()


# Instantiate the Aer simulator
sim = AerSimulator(method='statevector')


# Get the encoding circuit
# for each pattern (flower)
qcs = [qc_p.assign_parameters( {x_par : x_i} ) for x_i in X]

# Optimize all circuits and run simulation on them
qcts = transpile(qcs, sim)

# Execution
result = sim.run(qcts, shots=1).result()

# Get results
svs = [result.get_statevector(qc) for qc in qcts]

print('First sample: ', X[0, :])
print('\tQuantum state of the first sample: ', svs[0])

print('Last sample: ', X[-1, :])
print('\tQuantum state of the last sample: ', svs[-1])