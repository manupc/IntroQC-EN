"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""







import numpy as np

# Load data
dataset= np.load('iris.npy', allow_pickle=True).item()

# Get specimen features
X = dataset['data']
print('Features shape: {}'.format(X.shape))
print('Meaning of each column:')
for i, name in enumerate(dataset['feature_names']):
    print('\tColumn {}: {}'.format(i, name))


# Get the species of each specimen
Y_names = ['Setosa', 'Versicolor', 'Virginica']
Y = dataset['target']
print('\nSpecies shape: {}'.format(Y.shape))

print('Existing species: ')
for i, name in zip(np.unique(Y), Y_names):
    print('\tValue {}: species {}'.format(i, name))

print('\nFeatures of the first sample: ', X[0, :])
print('Species of the first sample: {}'.format(Y_names[Y[0]]))

print('\nFeatures of the last sample: ', X[-1, :])
print('Species of the last sample: {}'.format(Y_names[Y[-1]]))