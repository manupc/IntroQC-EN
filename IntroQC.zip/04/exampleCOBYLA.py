"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt


# Dataset creation

# Input features
X = np.linspace(start=-10, stop=10, num=101)

# Expected output values (supposedly unknown a priori)
epsilon = 2 * np.random.randn(len(X))
Y = 1.5 * (X**2) - 1.5 * X + 7 + epsilon

f = plt.figure()
plt.plot(X, Y, '.')
plt.title('Initial Dataset')

# Definition of the linear model f1
def model_f1(X, thetas):
    return X * thetas[1] + thetas[0]

# Definition of the quadratic model f2
def model_f2(X, thetas):
    return thetas[0] + thetas[1] * X + thetas[2] * (X**2)

# Error function
def error(y, y_hat):
    return np.sum(np.abs(y - y_hat))

# Function to calculate the performance of model 1
E_f1 = lambda thetas : error(Y, model_f1(X, thetas))

# Function to calculate the performance of model 2
E_f2 = lambda thetas : error(Y, model_f2(X, thetas))


# Initial values for the parameters of model f1
thetas_init = np.random.rand(2)
print('Initial theta values for f1:', thetas_init)

# Optimization of model f1 with COBYLA
result = minimize(fun=E_f1,
                  x0=thetas_init,
                  method='COBYLA')
f1_param_star = result.x # Get optimized parameters


# Initial values for the parameters of model f2
thetas_init = np.random.rand(3)
print('Initial theta values for f2:', thetas_init)

# Optimization of model f2 with COBYLA
result = minimize(fun=E_f2,
                  x0=thetas_init,
                  method='COBYLA')
f2_param_star = result.x # Get optimized parameters


# Prediction with the optimal parameters of both models
y_hat_f1 = model_f1(X, f1_param_star)
y_hat_f2 = model_f2(X, f2_param_star)

print('Model f1 produces an error of {} with parameters {}'.format(error(Y, y_hat_f1), f1_param_star))
print('\t Model f1 is: f(x)= {:.2f}x + {:.2f}'.format(f1_param_star[1], f1_param_star[0]))
print('Model f2 produces an error of {} with parameters {}'.format(error(Y, y_hat_f2), f2_param_star))
print('\t Model f2 is: f(x)= {:.2f}x**2 + {:.2f}x + {:.2f}'.format(f2_param_star[2], f2_param_star[1], f2_param_star[0]))

f = plt.figure()
plt.plot(X, Y, '.') # Initial data
plt.plot(X, y_hat_f1, 'g') # Data predicted by model 1
plt.plot(X, y_hat_f2, 'r') # Data predicted by model 2
plt.legend(['actual', 'f1', 'f2'])
plt.show()