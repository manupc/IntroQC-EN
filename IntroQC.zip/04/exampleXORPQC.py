"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""





from IPython.display import display
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

# Dataset creation
data = np.array([
        [0, 0, 0], # x1=0, x2=0, y=0
        [0, 1, 1], # x1=0, x2=1, y=1
        [1, 0, 1], # x1=1, x2=0, y=1
        [1, 1, 0], # x1=1, x2=1, y=0
      ])

X, Y = data[:, :-1], data[:, -1] # Get inputs X and outputs Y

# Circuit parameters array
thetas = ParameterVector('theta', 2)

# Parameter values
thetas_val = X * np.pi


# State preparation circuit
qc_p = QuantumCircuit(1)
qc_p.h(0)
qc_p.p(thetas[0], 0)
qc_p.p(thetas[1], 0)

# Ansatz circuit
qc_a = QuantumCircuit(1)
qc_a.h(0)

# Final circuit
qc = qc_p.compose(qc_a)
qc.measure_all()

# Final Circuit:
display(qc.draw('mpl'))

# Parameter assignment: As many circuits as options
sim = AerSimulator()
allCircuits = [transpile(qc.assign_parameters({thetas: values}), sim) for values in thetas_val]

# Simulation
result = sim.run(allCircuits, shots=1).result()

# Check results
y_pred = [] # List of algorithm outputs
for x, y, qct in zip(X, Y, allCircuits):
    counts = sim.run(qct, shots=1).result().get_counts()
    y_pred.append(0 if '0' in counts else 1)
    print('XOR({}, {})= {} and the circuit returns {}'.format(x[0], x[1], y, y_pred[-1]))

# Calculate how many times we were correct
accuracy = np.mean(Y == y_pred)
print('We were correct {}% of the times'.format(accuracy * 100))