"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import PhaseGate
from qiskit_aer import AerSimulator
from qiskit.quantum_info import Statevector
import numpy as np


## Example of PhaseGate usage
qc = QuantumCircuit(1)
qc.h(0)

PGate = PhaseGate(theta=np.pi / 2)
qc.append(PGate, [0])

# Save the unitary matrix of the circuit
qc.save_statevector()

# Aer simulator instantiation
simulator = AerSimulator(method='statevector')

# Rewrite circuit to meet device conditions
# where it will be executed
qct = transpile(qc, simulator)

# Aer simulator instantiation
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResult of applying P(pi/2)|+>:', sv)
print('|i>:', Statevector.from_label('r'))


## Example of Tdg usage
qc = QuantumCircuit(1)
qc.h(0)
qc.p(theta=np.pi / 2, qubit=0)


# Save the unitary matrix of the circuit
qc.save_statevector()

# Rewrite circuit to meet device conditions
# where it will be executed
qct = transpile(qc, simulator)

# Aer simulator instantiation
result = simulator.run(qct, shots=1).result()
sv = result.get_statevector(qct)

print('\nResult of applying P(pi/2)|+>:', sv)
print('|i>:', Statevector.from_label('r'))