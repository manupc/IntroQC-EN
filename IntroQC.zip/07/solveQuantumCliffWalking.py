"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
from qiskit_aer import AerSimulator
import numpy as np


# Creation of quantum registers
qrR = QuantumRegister(size=1, name='qF')
qrC = QuantumRegister(size=3, name='qC')
qrA = QuantumRegister(size=3, name='qA')
crA = ClassicalRegister(size=3, name='cA')

# Input parameters
paramF = ParameterVector(name='f', length=1)
paramC = ParameterVector(name='c', length=3)


# Encoding and decision-making circuit
qc = QuantumCircuit(qrR, qrC, qrA, crA)

# Data encoding
qc.rx(paramF[0] * np.pi, qrR[0])
for i in range(3):
    qc.rx(paramC[i] * np.pi, qrC[i])

# Rule R1
qc.cx(qrR[0], qrA[0])

# Rule R2
CCCNOT = XGate().control(num_ctrl_qubits=3)
qc.append(CCCNOT, [qrC[0], qrC[1], qrC[2], qrA[2]])

# Rule R3
qc.ccx(qrA[0], qrA[2], qrA[1], ctrl_state='00')

# Measurement
qc.measure(qrA, crA)


sim = AerSimulator()

# Action selection function
def SelectAction(s_t):

    # Convert s to (f,c) in binary
    f_bin = bin(s_t // 12)[2:][::-1].rjust(2, '0')
    c_bin = bin(s_t % 12)[2:][::-1].rjust(4, '0')
    c_bin = [c_bin[0], c_bin[1], c_bin[3]]

    # Encode inputs to the circuit
    qc_param = transpile(qc.assign_parameters({paramF: [int(f_bin[0])],
                                               paramC: [int(x) for x in c_bin]
                                              }), sim)

    # Simulation
    counts = sim.run(qc_param, shots=1).result().get_counts(qc_param)
    ket = list(counts.keys())[0][::-1] # '100', '010', '001'
    a_t = ket.find('1') # Get position 0, 1, 2 where '1' is found
    return a_t


# Simulation in the environment
env = gym.make('CliffWalking-v1') # Create simulation environment

s, info = env.reset() # Environment initialization

# Example of character-environment interaction in 10 iterations
R_T = 0 # Total reward obtained
terminated, truncated = False, False
while not (terminated or truncated):

    s_t = s # Update current state
    a_t = SelectAction(s_t) # Select action to perform

    # Execute action and change environment
    s, r, terminated, truncated, info = env.step(a_t)
    R_T += r # Update total reward


print('Total reward obtained: R(T)={}'.format(R_T))
print('Problem solved: {}'.format(terminated))