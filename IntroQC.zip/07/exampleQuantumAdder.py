"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""


import numpy as np
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import ParameterVector
from qiskit.circuit.library import XGate
from qiskit_aer import AerSimulator

# Register size for addition
register_size = 4

# Quantum registers to store X, Y, and Z
qrX = QuantumRegister(size=register_size, name='qX')
qrY = QuantumRegister(size=register_size, name='qY')
qrZ = QuantumRegister(size=register_size, name='qZ')

# Quantum carry register
qrCarry = QuantumRegister(size=1, name='qCarry')

# Classical output register
cOutput = ClassicalRegister(size=register_size + 1, name='cOutput')


# Modular circuit: Single-qubit adder
def SingleQubitAdder():

    # CCCNOT operations (Controlled-Controlled-Controlled-NOT)
    CCCNOT_001 = XGate().control(num_ctrl_qubits=3, ctrl_state='001'[::-1]) # Effectively ctrl_state='100'
    CCCNOT_110 = XGate().control(num_ctrl_qubits=3, ctrl_state='110'[::-1]) # Effectively ctrl_state='011'

    # Qubit assignment (internal to the adder circuit):
    # q0: q_x; q1: q_y; q2: q_c; q3: q_z
    adder = QuantumCircuit(4, name='Adder')

    # Calculate qz = q_x + q_y + q_c (sum bit)
    adder.cx(0, 3) # q_z = q_x XOR q_z
    adder.cx(1, 3) # q_z = q_x XOR q_y XOR q_z
    adder.cx(2, 3) # q_z = q_x XOR q_y XOR q_c XOR q_z (Initially q_z is |0>, so q_z = q_x XOR q_y XOR q_c)

    # Update CARRY bit (q2)
    adder.append(CCCNOT_001, [0, 1, 3, 2])
    adder.append(CCCNOT_110, [0, 1, 3, 2])
    return adder.to_instruction()


# Quantum circuit for a 4-qubit register adder
qc = QuantumCircuit(qrX, qrY, qrZ, qrCarry, cOutput)

# Data input
X = ParameterVector('X', register_size)
Y = ParameterVector('Y', register_size)

for i in range(register_size):
    qc.rx(theta=X[i] * np.pi, qubit=qrX[i]) # Encode X[i] (0 or 1) as |0> or |1> state
    qc.rx(theta=Y[i] * np.pi, qubit=qrY[i]) # Encode Y[i] (0 or 1) as |0> or |1> state

# Adder
qc_adder = SingleQubitAdder()
for i in range(register_size):    
    qc.append(qc_adder, [qrX[i], qrY[i], qrCarry[0], qrZ[i]])
qc.measure(qrZ[0:register_size] + [qrCarry[0]], cOutput)


# Prepare circuits with data inputs for simulation
sim = AerSimulator()
qcs = []
results = {} # Stores [qc_param, result_string] for each (x_number, y_number) pair
for x_number in range(2**register_size):
    bin_x = bin(x_number)[2:].rjust(register_size, '0')

    for y_number in range(2**register_size):
        bin_y = bin(y_number)[2:].rjust(register_size, '0')
        qcp = qc.assign_parameters({X: [int(v) for v in bin_x[::-1]],
                                    Y: [int(v) for v in bin_y[::-1]]})
        qcs.append(transpile(qcp, sim)) # Transpile for the simulator
        if bin_x not in results:
            results[bin_x] = {}
        results[bin_x][bin_y] = [qcp, 0] # Store the parameterized circuit and a placeholder for result


# Simulate all prepared circuits in a single batch run
r = sim.run(qcs, shots=1).result() # shots=1 is sufficient for exact state preparation
for bin_x in results:
    for bin_y in results[bin_x]:
        qcp = results[bin_x][bin_y][0]
        results[bin_x][bin_y][1] = list(r.get_counts(qcp).keys())[0]


# Display results and verify sums
sums_ok = 0 # Count of correctly performed additions
for bin_x in results:
    for bin_y in results[bin_x]:
        bin_o = results[bin_x][bin_y][1] # Get the output binary string from simulation
        int_x, int_y, int_o = int(bin_x, 2), int(bin_y, 2), int(bin_o, 2)
        if int_x + int_y == int_o:
            sums_ok += 1
        print('{} + {} = {}'.format(bin_x, bin_y, bin_o))

print('Total correctly performed sums: {} / {}'.format(sums_ok, 2**(2 * register_size)))