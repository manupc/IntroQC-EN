"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit import Parameter
from qiskit_aer import AerSimulator
import numpy as np



# Creation of quantum registers
qrPos = QuantumRegister(size=1, name='qPos')
qrVel = QuantumRegister(size=1, name='qVel')
qrA = QuantumRegister(size=3, name='qA')
crA = ClassicalRegister(size=3, name='cA')

# Input parameters
paramPos = Parameter(name='Pos')
paramVel = Parameter(name='Vel')


# Encoding and decision-making circuit
qc = QuantumCircuit(qrPos, qrVel, qrA, crA)

# Data encoding
qc.rx(paramPos, qrPos[0])
qc.rx(paramVel, qrVel[0])

# Rule R1
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[2])

# Rule R2
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[1], ctrl_state='0')

# Rule R3
qc.cx(control_qubit=qrPos[0], target_qubit=qrA[1])

# Rule R4
qc.cx(control_qubit=qrVel[0], target_qubit=qrA[0], ctrl_state='0')


# Measurement
qc.measure(qrA, crA)
sim = AerSimulator()

# Action selection function
def SelectAction(s_t):

    posMinMax = [-1.2, 0.6]
    velMinMax = [-0.07, 0.07]

    # Transformation of position and velocity to angles
    angle_pos = np.pi * (s_t[0] - posMinMax[0]) / (posMinMax[1] - posMinMax[0])
    angle_vel = np.pi * (s_t[1] - velMinMax[0]) / (velMinMax[1] - velMinMax[0])


    # Encoding inputs to the circuit
    qc_par = transpile(qc.assign_parameters({paramPos: angle_pos,
                                             paramVel: angle_vel
                                            }), sim)

    # Simulation
    counts = sim.run(qc_par, shots=50).result().get_counts(qc_par)
    action_counts = [0, 0, 0]
    for ket in counts:
        if ket[::-1] == '100': # qL=1, qN= 0, qR=0
            action_counts[0] = counts[ket]
        elif ket[::-1] == '010': # qL=0, qN= 1, qR=0
            action_counts[1] = counts[ket]
        elif ket[::-1] == '001': # qL=0, qN= 0, qR=1
            action_counts[2] = counts[ket]

    a_t = np.argmax(action_counts) # a(t) = action with highest probability of |1>
    return a_t


# Simulation in the environment
env = gym.make('MountainCar-v0') # Create simulation environment
s, info = env.reset() # Environment initialization

# Example of character-environment interaction in 10 iterations
R_T = 0 # Total reward obtained
terminated, truncated = False, False
while not (terminated or truncated):

    s_t = s # Update current state
    a_t = SelectAction(s_t) # Select action to perform

    # Execute action and change environment
    s, r, terminated, truncated, info = env.step(a_t)
    R_T += r # Update total reward


print('Total reward obtained: R(T)={}'.format(R_T))
print('Reached destination: {}'.format(terminated))