"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym

# List of actions to execute
action_list = [0, 1, 2, 0, 3, 0]


# Creation of the simulation environment for CliffWalking-v0
env = gym.make('CliffWalking-v1')

# Example of calling the reset method
s, info = env.reset()
print('Simulation start. Cell: {} -> ({}, {})'.format(s, s // 12, s % 12))

# Example of agent-environment interaction in 10 iterations
R_T = 0 # Total reward obtained
t = 0
while action_list:

    # Selection of action to perform
    s_t = s
    a_t = action_list.pop(0)

    print('Iteration t={}'.format(t))
    print('\tI am in cell: s(t)={} -> ({}, {})'.format(s_t, s_t // 12, s_t % 12))
    print('\tI select action: a(t)={}'.format(a_t))

    # Execution of action and change of environment
    s, r, terminated, truncated, info = env.step(a_t)
    R_T += r # Update total reward
    print('\tThis results in r(t+1)={} and I move to s(t+1)={}'.format(r, s))
    print('\tThe current R(T) calculation is R(T)={}'.format(R_T))

    t = t + 1 # Advance to the next iteration