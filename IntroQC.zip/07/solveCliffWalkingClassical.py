"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






import gymnasium as gym
from time import sleep

# Action selection function
def SelectAction(s_t):
    if s_t == 36: # Cell (3,0)
        return 0
    elif s_t == 35: # Cell (2,11)
        return 2
    else: # Cells (2,0)-(2,10)
        return 1
    return None


render = False # Change to True to visualize with render() method
env = gym.make('CliffWalking-v1', render_mode='human' if render else None) # Create simulation environment

s, info = env.reset() # Environment initialization
if render:
    sleep(0.01)
    env.render() # Graphical visualization

# Example of character-environment interaction in 10 iterations
R_T = 0 # Total reward obtained
terminated, truncated = False, False
while not (terminated or truncated):

    s_t = s # Update current state
    a_t = SelectAction(s_t) # Select action to perform

    # Execute action and change environment
    s, r, terminated, truncated, info = env.step(a_t)
    R_T += r # Update total reward

    if render:
        sleep(0.01)
        env.render()

print('Total reward obtained: R(T)={}'.format(R_T))
print('Problem solved: {}'.format(terminated))

if render:
    print('Press any key to continue...')
    _ = input()
    env.close()
