"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.visualization import plot_histogram
from qiskit.quantum_info import Statevector, DensityMatrix
from IPython.display import display


# Histogram after measurement simulation of the |0> state
N = 1024
sv = Statevector.from_label('0')
print('\nQuantum state |0> in Qiskit:\n{}'.format(sv))
counts = sv.sample_counts(shots=N)
print('Results after {} measurements: {}'.format(N, counts))
f = plot_histogram(counts)
display(f)


# Histogram after measurement simulation of the |-> state
sv = Statevector.from_label('-')
print('\nQuantum state |-> in Qiskit:\n{}'.format(sv))
counts = sv.sample_counts(shots=N)
print('Results after {} measurements: {}'.format(N, counts))
f = plot_histogram(counts)
display(f)


# Q-sphere of the |i> state
sv = Statevector.from_label('r')
print('\nQuantum state |i> in Qiskit:\n{}'.format(sv))
f = sv.draw(output='qsphere')
display(f)


# Hinton diagram of the |-i> state
sv = Statevector.from_label('l')
dm = DensityMatrix(sv)
print('\nDensity matrix of the |-i> state:\n{}'.format(dm))
f = dm.draw(output='hinton')
display(f)


# Hinton diagram of the |1> state
sv = Statevector.from_label('1')
dm = DensityMatrix(sv)
print('\nQuantum state |1> in Qiskit:\n{}'.format(sv))
print('Its density matrix:\n{}'.format(dm))
f = dm.draw(output='hinton')
display(f)