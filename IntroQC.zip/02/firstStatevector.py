"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

# Creation of |0>, |1>, and |+> in NumPy
np_ket0 = np.array([1, 0], dtype=complex)
np_ket1 = np.array([0, 1], dtype=complex)
np_ketplus = np.array([1/np.sqrt(2), 1/np.sqrt(2)], dtype=complex)

# Creation of |0>, |1>, and |+> in Qiskit
ket0 = Statevector(np_ket0)
ket1 = Statevector(np_ket1)
ketplus = Statevector(np_ketplus)
print('Creating state from NumPy:')
print('|0> = \n{}'.format(ket0))
print('\n|1> = \n{}'.format(ket1))
print('\n|+> = \n{}'.format(ketplus))


# Using from_int to create |0> and |1>
ket0 = Statevector.from_int(i=0, dims=2)
ket1 = Statevector.from_int(i=1, dims=2)
print('\nCreating state with from_int:')
print('|0> = \n{}'.format(ket0))
print('\n|1> = \n{}'.format(ket1))

# Using from_label to create |0>, |1>, and |+>
ket0 = Statevector.from_label('0')
ket1 = Statevector.from_label('1')
ketplus2 = Statevector.from_label('+')
print('\nCreating state with from_label:')
print('|0> = \n{}'.format(ket0))
print('\n|1> = \n{}'.format(ket1))
print('\n|+> = \n{}'.format(ketplus2))