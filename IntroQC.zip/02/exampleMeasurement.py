"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

# Creation of |0> and |+> using Qiskit
ket0 = Statevector.from_label('0')
ket_plus = Statevector.from_label('+')

# Example of using probabilities()
print('Example of using the probabilities() method vs. manual calculation for |0>:')
p_ket0 = np.abs(ket0.data)**2
print('Probabilities for |0>: {}'.format(ket0.probabilities()))
print('Probabilities for |0> (manual): {}'.format(p_ket0))


# Example of using probabilities()
print('\nExample of using the probabilities() method vs. manual calculation for |+>:')
p_ket_plus = np.abs(ket_plus.data)**2
print('Probabilities for |+>: {}'.format(ket_plus.probabilities()))
print('Probabilities for |+> (manual): {}'.format(p_ket_plus))


# Example of using probabilities_dict()
print('\nExample of using the probabilities_dict() method:')
print('Probabilities for |0>: {}'.format(ket0.probabilities_dict()))
print('Probabilities for |+>: {}'.format(ket_plus.probabilities_dict()))


# Example of using measure()
shots = 2  # Number of measurement simulations to perform
print('\nExample of using the measure() method:')
for i in ['0', '+']:
    ket = Statevector.from_label(i)
    print('Measurement simulation on the |{}> ket:'.format(i))
    for n in range(shots):
        outcome, sv = ket.measure()
        print('Simulation {}. Outcome is |{}> = {}'.format(n + 1, outcome, sv))
        
        