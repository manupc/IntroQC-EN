"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector

# Example of using sample_memory
shots = 10  # Number of measurement simulations to perform
print('\nExample of using the sample_memory() method:')
for i in ['0', '+']:
    ket = Statevector.from_label(i)
    # Renamed to 'memory' to better reflect the list of outcomes returned
    memory = ket.sample_memory(shots)
    print('Measurement simulation on the |{}> ket: {}'.format(i, memory))


# Example of using sample_counts
shots = 1000  # Number of measurement simulations to perform
print('\nExample of using the sample_counts() method:')
for i in ['0', '+']:
    ket = Statevector.from_label(i)
    counts = ket.sample_counts(shots)
    print('Measurement simulation on the |{}> ket: {}'.format(i, counts))