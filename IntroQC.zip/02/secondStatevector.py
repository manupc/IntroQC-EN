"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

# Creation of |0>, |1>, and |+> in NumPy
np_ket0 = np.array([1, 0], dtype=complex)
np_ket1 = np.array([0, 1], dtype=complex)
np_ketplus = np.array([1/np.sqrt(2), 1/np.sqrt(2)], dtype=complex)

# Creation of |0>, |1>, and |+> in Qiskit
ket0 = Statevector(np_ket0)
ket1 = Statevector(np_ket1)
ketplus = Statevector(np_ketplus)

# Accessing the attributes of a state
print('The state |+> uses {} qubit(s) and needs {} amplitudes.'.format(ketplus.num_qubits, ketplus.dim))
print('Its amplitudes are: {}'.format(ketplus.data))

# Transforming a state into a dictionary
ketplus_dict = ketplus.to_dict()
print('In dictionary format, it is: {}'.format(ketplus_dict))

# Checking the validity of a quantum state
print('\nChecking how is_valid works:')
ketError = Statevector([2, 0])  # Creation of an invalid quantum state
print('Is the state |0> valid?: {}'.format(ket0.is_valid()))
print('Is the state |error> valid?: {}'.format(ketError.is_valid()))

# Example of conjugate and inner
print('\nChecking how conjugate and inner work:')
np_ket_psi = np.array([1/np.sqrt(2), 1/np.sqrt(2)*1.j], dtype=complex)
ket_psi = Statevector(np_ket_psi)
print('The state |psi> is:\n{}'.format(ket_psi))
print('\nIts conjugate is:\n{}'.format(ket_psi.conjugate()))
print('\nThe product <0|1> is: {}'.format(ket0.inner(ket1)))
print('The product <0|psi> is: {}'.format(ket0.inner(ket_psi)))
print('The product <psi|psi> is: {}'.format(ket_psi.inner(ket_psi)))
