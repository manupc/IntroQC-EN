"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
from SingleQubitUtils import MPStatevector
import numpy as np

# Creation of |0>, |1>, |+>, and |psi> states with Statevector
ket0= Statevector.from_label('0')
ket1= Statevector.from_label('1')
ketplus= Statevector.from_label('+')
ketpsi= Statevector([ 1/np.sqrt(2), 1.j/np.sqrt(2) ])

# Tests for the from_Statevector method
mp_ket0= MPStatevector.from_Statevector( ket0 )
mp_ket1= MPStatevector.from_Statevector( ket1 )
mp_ketplus= MPStatevector.from_Statevector( ketplus )
mp_ketpsi= MPStatevector.from_Statevector( ketpsi )

print('State |0>. The magnitude and phase form {} corresponds to the state:\n{}'.format(mp_ket0, ket0))
print('State |1>. The magnitude and phase form {} corresponds to the state:\n{}'.format(mp_ket1, ket1))
print('State |+>. The magnitude and phase form {} corresponds to the state:\n{}'.format(mp_ketplus, ketplus))
print('State |psi>. The magnitude and phase form {} corresponds to the state:\n{}'.format(mp_ketpsi, ketpsi))


# Example of to_Statevector
mp_ketminus= MPStatevector([ 1/np.sqrt(2), 1/np.sqrt(2), np.pi ])
ketminus= mp_ketminus.to_Statevector()
print('State |->. The magnitude and phase form {} corresponds to the state:\n{}'.format(mp_ketminus, ketminus))