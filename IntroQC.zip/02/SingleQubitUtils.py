"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
import numpy as np

tol_default= 1e-5 # Default allowed error tolerance

# Class to represent a single-qubit quantum state in exponential form
class ExpStatevector:

    # Constructor. Creates an object to represent a Statevector in exponential form
    # INPUTS:
    #   data: Array containing the values [r0, theta0, r1, theta1]
    def __init__(self, data):
        assert(len(data) == 4)
        self.__r= np.array([data[0], data[2]], dtype=float)
        self.__theta= np.array([data[1], data[3]], dtype=float)
        assert(self.__is_valid())


    # Returns the number of qubits used to represent the quantum state
    def num_qubits(self):
        return 1


    # Checks if the represented quantum state is valid
    # INPUTS:
    #   tol: Allowed error tolerance
    def __is_valid(self, tol : float= tol_default):
        return (np.abs(np.sum( np.abs(self.__r)**2 ) - 1)<=tol)


    # Overloads __str__
    def __str__(self):
        txt= '{:.3f}e^({:.3f}*i) |0> + {:.3f}e^({:.3f}*i) |1>'.format(
            self.__r[0], self.__theta[0], self.__r[1], self.__theta[1])
        return txt


    # Accesses the magnitudes of the quantum state's amplitudes
    # INPUTS:
    #   i: Index of the magnitude r_i to access
    # OUTPUTS:
    #   The magnitude r_i of the quantum state
    def r(self, i : int):
        assert(0<=i<2)
        return self.__r[i]


    # Accesses the phases of the quantum state's amplitudes
    # INPUTS:
    #   i: Index of the phase theta_i to access
    # OUTPUTS:
    #   The phase theta_i of the quantum state
    def theta(self, i : int):
        assert(0<=i<2)
        return self.__theta[i]


    # Converts the current object to a Qiskit Statevector object
    # OUTPUTS:
    #   A Qiskit Statevector object containing the state vector represented in the current object
    def to_Statevector(self):
        sv= [self.__r[0]*np.exp(1.j*self.__theta[0]), 
             self.__r[1]*np.exp(1.j*self.__theta[1])]
        return Statevector(sv)
    
    
    # Creates an ExpStatevector object from a Qiskit Statevector object
    # INPUTS:
    #   sv: A valid Qiskit Statevector object
    # OUTPUTS:
    #   An ExpStatevector object equivalent to the input sv object
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        r1, theta1= np.abs(sv.data[1]), np.angle(sv.data[1])
        return ExpStatevector([r0, theta0, r1, theta1])
    
    


# Class to represent a single-qubit quantum state in magnitude and phase form
class MPStatevector:

    # Constructor. Creates an object to represent a Statevector in magnitude and phase form
    # INPUTS:
    #   data: Array containing the values [r0, r1, theta]
    def __init__(self, data):
        assert(len(data) == 3)
        self.__r= np.array([data[0], data[1]], dtype=float)
        self.__theta= float( data[2] )
        assert(self.__is_valid())


    # Returns the number of qubits used to represent the quantum state
    def num_qubits(self):
        return 1


    # Checks if the represented quantum state is valid
    # INPUTS:
    #   tol: Allowed error tolerance
    def __is_valid(self, tol : float= tol_default):
        return (np.abs(np.sum( np.abs(self.__r)**2 ) - 1)<=tol)


    # Overloads __str__
    def __str__(self):
        txt= '{:.3f} |0> + {:.3f}e^({:.3f}*i) |1>'.format(
            self.__r[0], self.__r[1], self.__theta)
        return txt
    
    
    # Accesses the magnitudes of the quantum state's amplitudes
    # INPUTS:
    #   i: Index of the magnitude r_i to access
    # OUTPUTS:
    #   The magnitude r_i of the quantum state
    def r(self, i : int):
        assert(0<=i<2)
        return self.__r[i]


    # Accesses the relative phase of the quantum state
    # OUTPUTS:
    #   The phase theta of the quantum state
    def theta(self):
        return self.__theta

    
    # Converts the current object to a Qiskit Statevector object
    # OUTPUTS:
    #   A Qiskit Statevector object containing the state vector represented in the current object
    def to_Statevector(self):
        sv= [self.__r[0], self.__r[1]*np.exp(1.j*self.__theta)]
        return Statevector(sv)
    
    
    # Creates an MPStatevector object from a Qiskit Statevector object
    # INPUTS:
    #   sv: A valid Qiskit Statevector object
    # OUTPUTS:
    #   An MPStatevector object equivalent to the input sv object
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        r1, theta1= np.abs(sv.data[1]), np.angle(sv.data[1])
        theta= theta1-theta0
        return MPStatevector([r0, r1, theta])







# Class to represent a single-qubit quantum state in trigonometric form
class TriStatevector:

    # Constructor. Creates an object to represent a Statevector in trigonometric form
    # INPUTS:
    #   data: Array containing the values [phi, theta]
    def __init__(self, data):
        assert(len(data) == 2)
        self.__phi= float( data[0] )
        self.__theta= float( data[1] )
        assert(self.__is_valid())


    # Returns the number of qubits used to represent the quantum state
    def num_qubits(self):
        return 1


    # Checks if the represented quantum state is valid
    # INPUTS:
    #   tol: Allowed error tolerance
    def __is_valid(self, tol : float= tol_default):
        return True


    # Overloads __str__
    def __str__(self):
        txt= 'cos({:.3f}/2)|0> + sin({:.3f}/2)*exp(i*{:.3f})|1>'.format(self.__phi, self.__phi, self.__theta)
        return txt


    # Accesses the phi angle that controls the state's magnitude
    # OUTPUTS:
    #   The phi angle of the quantum state in trigonometric form
    def phi(self):
        return self.__phi


    # Accesses the relative phase of the quantum state
    # OUTPUTS:
    #   The phase theta of the quantum state
    def theta(self):
        return self.__theta


    # Converts the current object to a Qiskit Statevector object
    # OUTPUTS:
    #   A Qiskit Statevector object containing the state vector represented in the current object
    def to_Statevector(self):
        sv= [np.cos(0.5*self.__phi), 
             np.sin(0.5*self.__phi)*np.exp(1.j*self.__theta)]
        return Statevector(sv)   
    
    # Creates a TriStatevector object from a Qiskit Statevector object
    # INPUTS:
    #   sv: A valid Qiskit Statevector object
    # OUTPUTS:
    #   A TriStatevector object equivalent to the input sv object
    def from_Statevector(sv : Statevector):
        
        r0, theta0= np.abs(sv.data[0]), np.angle(sv.data[0])
        theta1= np.angle(sv.data[1])
        theta= theta1-theta0
        phi= 2*np.arccos(r0)
        return TriStatevector([phi, theta])  





# Function that calculates the Cartesian coordinates (x, y, z) of a single-qubit quantum state
# INPUTS: 
#   sv: a Statevector object containing the single-qubit quantum state
# OUTPUTS:
#   A tuple (x, y, z) with the Cartesian coordinates of the state on the Bloch sphere
def Statevector_to_cartesian(sv : Statevector):
    assert(sv.num_qubits == 1)
    
    # Convert the state to trigonometric form
    tri_sv= TriStatevector.from_Statevector(sv)
    phi, theta= tri_sv.phi(), tri_sv.theta()
    
    z= np.cos(phi)
    y= np.sin(phi) * np.sin(theta)
    x= np.sin(phi) * np.cos(theta)
    return (x, y, z)