"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector, DensityMatrix
import numpy as np


# |0> state
sv= Statevector.from_label('0')
rho= DensityMatrix(sv)
print('State |0>: \n{}  \nMatrix:\n{}'.format(sv, rho))


# |+> state
sv= Statevector.from_label('+')
rho= DensityMatrix(sv)
print('\nState |+>: \n{}  \nMatrix:\n{}'.format(sv, rho))


# |i> state
sv= Statevector.from_label('r')
rho= DensityMatrix(sv)
print('\nState |i>: \n{}  \nMatrix:\n{}'.format(sv, rho))


# Creation of |-i> from a density matrix
rho_minus_i= np.array([ [0.5, 0.5j],
                       [-0.5j, 0.5]
                     ], dtype= complex)
rho= DensityMatrix(rho_minus_i)
sv= rho.to_statevector()
print('\nState |-i>: \n{}  \nMatrix:\n{}'.format(sv, rho))



# Creation of a mixed state from a density matrix
rho_mixed = np.array([ [0.5, 0],
                       [0, 0.5]
                     ], dtype= complex)
rho= DensityMatrix(rho_mixed)
print('\nDensity matrix of a mixed state:\n{}'.format(rho))
print('The matrix is valid: {}'.format(rho.is_valid()))
try:
    sv= rho.to_statevector()
    print('State vector: \n{}'.format(sv))
except:
    print('Error converting matrix to state vector')