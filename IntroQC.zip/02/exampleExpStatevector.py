"""
This program is free software: you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
more details.

You should have received a copy of the GNU General Public License along with 
this program. If not, see <https://www.gnu.org/licenses/>. 
"""






from qiskit.quantum_info import Statevector
from SingleQubitUtils import ExpStatevector
import numpy as np

# Creation of |0>, |1>, |+>, and |psi> states with Statevector
ket0= Statevector.from_label('0')
ket1= Statevector.from_label('1')
ketplus= Statevector.from_label('+')
ketpsi= Statevector([ 1/np.sqrt(2), 1.j/np.sqrt(2) ])

# Tests for the from_Statevector method
exp_ket0= ExpStatevector.from_Statevector( ket0 )
exp_ket1= ExpStatevector.from_Statevector( ket1 )
exp_ketplus= ExpStatevector.from_Statevector( ketplus )
exp_ketpsi= ExpStatevector.from_Statevector( ketpsi )

print('State |0>. The exponential form {} corresponds to the state:\n{}'.format(exp_ket0, ket0))
print('State |1>. The exponential form {} corresponds to the state:\n{}'.format(exp_ket1, ket1))
print('State |+>. The exponential form {} corresponds to the state:\n{}'.format(exp_ketplus, ketplus))
print('State |psi>. The exponential form {} corresponds to the state:\n{}'.format(exp_ketpsi, ketpsi))


# Example of to_Statevector
exp_ketminus= ExpStatevector([ 1/np.sqrt(2), 0, 1/np.sqrt(2), np.pi ])
ketminus= exp_ketminus.to_Statevector()
print('State |->. The exponential form {} corresponds to the state:\n{}'.format(exp_ketminus, ketminus))